<#
.SYNOPSIS
    Backs up or restores System32 and SysWOW64 ACLs before hardening.

.DESCRIPTION
    Replaces ptb/bear.ps1 with clean error handling, -WhatIf support, and -Restore mode.

.EXAMPLE
    .\2-BackupSystemACLs.ps1
    .\2-BackupSystemACLs.ps1 -Restore
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$OutDir = 'C:\tools\logs',
    [switch]$Restore
)

$ErrorActionPreference = 'Stop'

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run 2-BackupSystemACLs.ps1 as Administrator.'
}

if (-not (Test-Path $OutDir)) {
    New-Item -ItemType Directory -Path $OutDir -Force | Out-Null
}

$sys32Acl  = Join-Path $OutDir 'System32_ACLs.txt'
$wow64Acl  = Join-Path $OutDir 'SysWOW64_ACLs.txt'
$sys32Path = Join-Path $env:SystemRoot 'System32'
$wow64Path = Join-Path $env:SystemRoot 'SysWOW64'

if ($Restore) {
    if (Test-Path $sys32Acl) {
        if ($PSCmdlet.ShouldProcess($sys32Path, "Restore ACLs from $sys32Acl")) {
            Write-Host "[*] Restoring System32 ACLs..." -ForegroundColor Yellow
            & icacls.exe $env:SystemRoot /restore $sys32Acl /c /q
        }
    } else {
        Write-Warning "Backup not found: $sys32Acl"
    }
    if ((Test-Path $wow64Path) -and (Test-Path $wow64Acl)) {
        if ($PSCmdlet.ShouldProcess($wow64Path, "Restore ACLs from $wow64Acl")) {
            Write-Host "[*] Restoring SysWOW64 ACLs..." -ForegroundColor Yellow
            & icacls.exe $env:SystemRoot /restore $wow64Acl /c /q
        }
    }
    Write-Host '[+] ACL restore finished.' -ForegroundColor Green
    return
}

if ($PSCmdlet.ShouldProcess($sys32Acl, "Save System32 ACLs")) {
    Write-Host "[*] Saving System32 ACLs -> $sys32Acl" -ForegroundColor Cyan
    & icacls.exe $sys32Path /save $sys32Acl /t /c /q
    Write-Host "[+] Saved $sys32Acl" -ForegroundColor Green
}

if (Test-Path $wow64Path) {
    if ($PSCmdlet.ShouldProcess($wow64Acl, "Save SysWOW64 ACLs")) {
        Write-Host "[*] Saving SysWOW64 ACLs -> $wow64Acl" -ForegroundColor Cyan
        & icacls.exe $wow64Path /save $wow64Acl /t /c /q
        Write-Host "[+] Saved $wow64Acl" -ForegroundColor Green
    }
}
