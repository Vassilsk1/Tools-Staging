<#
.SYNOPSIS
    Enables comprehensive Windows logging across Windows 10, 11, and Server 2016/2019/2022/2025.

.DESCRIPTION
    Universal logging script compatible with PowerShell 5.1+ on Windows 10/11 and Windows Server
    2016, 2019, 2022, and 2025. Enables:
      - Full auditpol (all categories Success + Failure) & SCENoApplyLegacyAuditPolicy
      - Process Creation (4688) with command-line arguments
      - PowerShell 64-bit & 32-bit ScriptBlock, Module, and Transcript logging
      - Expanded Event Log sizes (Security, System, Application, PS, TaskScheduler, WMI, WinRM, RDP, SMB)
      - Windows Firewall logging (Domain, Private, Public - allowed & dropped connections)
      - Sysmon64 install/update with SwiftOnSecurity config + 128 MB Operational log (skip with -SkipSysmon)

.EXAMPLE
    .\11-EnableAllLogging.ps1
    .\11-EnableAllLogging.ps1 -SkipSysmon
    .\11-EnableAllLogging.ps1 -WhatIf
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [switch]$SkipSysmon,
    [switch]$ForceSysmon,
    [string]$LogDir = 'C:\tools\logs'
)

$ErrorActionPreference = 'Continue'

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run 11-EnableAllLogging.ps1 from an elevated (Administrator) PowerShell session.'
}

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

foreach ($d in @($LogDir, (Join-Path $LogDir 'PS_Transcripts'), 'C:\tools\bins\Sysmon', 'C:\tools\zips')) {
    if (-not (Test-Path $d)) {
        if ($PSCmdlet.ShouldProcess($d, 'Create directory')) {
            New-Item -ItemType Directory -Path $d -Force | Out-Null
        }
    }
}

$scriptLog = Join-Path $LogDir "EnableAllLogging_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
function Write-Log {
    param([string]$Message, [ConsoleColor]$Color = 'Gray')
    Add-Content -Path $scriptLog -Value "$(Get-Date -Format 's') $Message"
    Write-Host $Message -ForegroundColor $Color
}

function Set-RegValue {
    param([string]$Path, [string]$Name, [object]$Value, [string]$Type = 'DWord')
    if ($PSCmdlet.ShouldProcess("$Path\$Name", "Set $Type = $Value")) {
        try {
            if (-not (Test-Path $Path)) { New-Item -Path $Path -Force -ErrorAction Stop | Out-Null }
            New-ItemProperty -Path $Path -Name $Name -Value $Value -PropertyType $Type -Force -ErrorAction Stop | Out-Null
        } catch {
            Write-Log "[!] Could not set $Path\$Name : $($_.Exception.Message)" Yellow
        }
    }
}

# 1. Audit Policy (Win 10/11 + Server 2016/2019/2022/2025)
Write-Log '[*] Enabling full Audit Policy (auditpol) & subcategory override...' Cyan
Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -Name 'SCENoApplyLegacyAuditPolicy' -Value 1
if ($PSCmdlet.ShouldProcess('auditpol', 'Enable success + failure on all categories')) {
    & auditpol.exe /set /category:* /success:enable /failure:enable | Out-Null
    Write-Log '[+] Audit policy enabled for all categories.' Green
}

# 2. Process Creation (4688) CLI + PowerShell Logging (64-bit & 32-bit)
Write-Log '[*] Enabling 4688 Command-Line Auditing and PowerShell ScriptBlock/Module/Transcript logging...' Cyan
Set-RegValue -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit' -Name 'ProcessCreationIncludeCmdLine_Enabled' -Value 1

foreach ($psRoot in @(
    'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell',
    'HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\PowerShell'
)) {
    Set-RegValue -Path "$psRoot\ScriptBlockLogging" -Name 'EnableScriptBlockLogging' -Value 1
    Set-RegValue -Path "$psRoot\ScriptBlockLogging" -Name 'EnableScriptBlockInvocationLogging' -Value 1
    Set-RegValue -Path "$psRoot\ModuleLogging" -Name 'EnableModuleLogging' -Value 1
    Set-RegValue -Path "$psRoot\ModuleLogging\ModuleNames" -Name '*' -Value '*' -Type String
    Set-RegValue -Path "$psRoot\Transcription" -Name 'EnableTranscripting' -Value 1
    Set-RegValue -Path "$psRoot\Transcription" -Name 'EnableInvocationHeader' -Value 1
    Set-RegValue -Path "$psRoot\Transcription" -Name 'OutputDirectory' -Value (Join-Path $LogDir 'PS_Transcripts') -Type String
}
Write-Log '[+] 4688 + PowerShell logging enabled.' Green

# 3. Expand & Enable Key Windows Event Logs (wevtutil works across all versions)
Write-Log '[*] Expanding and enabling key Windows Event Logs...' Cyan
$eventLogs = @(
    @{ Name = 'Security'; Size = 268435456 },
    @{ Name = 'System'; Size = 134217728 },
    @{ Name = 'Application'; Size = 134217728 },
    @{ Name = 'Windows PowerShell'; Size = 67108864 },
    @{ Name = 'Microsoft-Windows-PowerShell/Operational'; Size = 134217728 },
    @{ Name = 'Microsoft-Windows-TaskScheduler/Operational'; Size = 67108864 },
    @{ Name = 'Microsoft-Windows-TerminalServices-LocalSessionManager/Operational'; Size = 67108864 },
    @{ Name = 'Microsoft-Windows-WinRM/Operational'; Size = 67108864 },
    @{ Name = 'Microsoft-Windows-WMI-Activity/Operational'; Size = 67108864 },
    @{ Name = 'Microsoft-Windows-SMBServer/Security'; Size = 67108864 },
    @{ Name = 'Microsoft-Windows-DNS-Client/Operational'; Size = 67108864 }
)

$role = (Get-CimInstance Win32_ComputerSystem).DomainRole
if ($role -in 4, 5) {
    $eventLogs += @{ Name = 'Directory Service'; Size = 134217728 }
    if (Get-Service -Name DNS -ErrorAction SilentlyContinue) {
        $eventLogs += @{ Name = 'DNS Server'; Size = 134217728 }
    }
}

foreach ($log in $eventLogs) {
    if ($PSCmdlet.ShouldProcess($log.Name, "Enable and set max size $($log.Size)")) {
        & wevtutil.exe sl "$($log.Name)" /e:true /ms:$($log.Size) 2>$null
    }
}
Write-Log '[+] Event logs enabled and resized.' Green

# 4. Windows Firewall Logging (netsh advfirewall works on Win 10/11 & Server 2016-2025)
Write-Log '[*] Enabling Windows Firewall logging (allowed + dropped) across all profiles...' Cyan
if ($PSCmdlet.ShouldProcess('netsh advfirewall', 'Enable logging on domain/private/public')) {
    foreach ($prof in @('domainprofile', 'privateprofile', 'publicprofile')) {
        & netsh.exe advfirewall set $prof logging filename "%SystemRoot%\System32\LogFiles\Firewall\pfirewall.log" | Out-Null
        & netsh.exe advfirewall set $prof logging maxfilesize 32767 | Out-Null
        & netsh.exe advfirewall set $prof logging droppedconnections enable | Out-Null
        & netsh.exe advfirewall set $prof logging allowedconnections enable | Out-Null
    }
    Write-Log '[+] Firewall logging enabled (%SystemRoot%\System32\LogFiles\Firewall\pfirewall.log).' Green
}

# 5. Sysmon Install & Operational Log
if (-not $SkipSysmon) {
    $sysmonSvc = Get-Service -Name 'Sysmon64','Sysmon' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($sysmonSvc -and -not $ForceSysmon) {
        Write-Log "[=] Sysmon service ($($sysmonSvc.Name)) already installed. Expanding Sysmon log..." DarkGray
        if ($PSCmdlet.ShouldProcess('Microsoft-Windows-Sysmon/Operational', 'Set max size 128 MB')) {
            & wevtutil.exe sl 'Microsoft-Windows-Sysmon/Operational' /e:true /ms:134217728 2>$null
        }
    } else {
        $sysZip = 'C:\tools\zips\Sysmon.zip'
        $sysDir = 'C:\tools\bins\Sysmon'
        $cfgXml = Join-Path $sysDir 'sysmonconfig-export.xml'
        $sysExe = Join-Path $sysDir 'Sysmon64.exe'

        if ($PSCmdlet.ShouldProcess('Sysmon64', 'Download & install Sysmon with SwiftOnSecurity config')) {
            try {
                Write-Host '[*] Downloading Sysmon & SwiftOnSecurity config...' -ForegroundColor Cyan
                Invoke-WebRequest -Uri 'https://download.sysinternals.com/files/Sysmon.zip' -OutFile $sysZip -UseBasicParsing -TimeoutSec 120
                Expand-Archive -Path $sysZip -DestinationPath $sysDir -Force
                Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/SwiftOnSecurity/sysmon-config/master/sysmonconfig-export.xml' -OutFile $cfgXml -UseBasicParsing -TimeoutSec 60

                if (-not (Test-Path $sysExe)) { $sysExe = Join-Path $sysDir 'Sysmon.exe' }
                if ($sysmonSvc) {
                    & $sysExe -c $cfgXml
                } else {
                    & $sysExe -accepteula -i $cfgXml
                }
                & wevtutil.exe sl 'Microsoft-Windows-Sysmon/Operational' /e:true /ms:134217728 2>$null
                Write-Log '[+] Sysmon installed/updated with SwiftOnSecurity config.' Green
            } catch {
                Write-Warning "Sysmon setup failed (use -SkipSysmon if offline): $($_.Exception.Message)"
            }
        }
    }
}

Write-Log "[+] 11-EnableAllLogging complete. Log: $scriptLog" Green
