<#
.SYNOPSIS
    CCDC Windows Firewall builder, logging enabler, and optional rule-change monitor.

.DESCRIPTION
    Replaces ptb/dawall.ps1. Ensures Windows Firewall (mpssvc) is running with logging
    enabled, preserves RDP (3389) and SSH (22), allows specified scored ports (-AllowPorts)
    or runs interactive prompts (-Interactive), and optionally adds an implicit deny or
    starts a live rule-change monitor.

.EXAMPLE
    .\8-FirewallBuilder.ps1 -AllowPorts 80,443,53
    .\8-FirewallBuilder.ps1 -Interactive
    .\8-FirewallBuilder.ps1 -AllowPorts 80,443 -AddImplicitDeny
    .\8-FirewallBuilder.ps1 -Monitor
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [int[]]$AllowPorts = @(),
    [switch]$Interactive,
    [switch]$AddImplicitDeny,
    [switch]$Monitor,
    [string]$LogDir = 'C:\tools\logs'
)

$ErrorActionPreference = 'Continue'

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run 8-FirewallBuilder.ps1 as Administrator.'
}

if (-not (Test-Path $LogDir)) {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
}
$fwLog = Join-Path $LogDir 'pfirewall.log'
$changeLog = Join-Path $LogDir 'FirewallChanges.log'

if ($Monitor) {
    Write-Host "[*] Monitoring Windows Firewall rule changes -> $changeLog (Ctrl+C to stop)..." -ForegroundColor Cyan
    $query = "SELECT * FROM __InstanceModificationEvent WITHIN 10 WHERE TargetInstance ISA 'MSFT_NetFirewallRule'"
    $watcher = New-Object Management.ManagementEventWatcher (New-Object Management.ManagementScope('\\.\root\StandardCimv2')), (New-Object Management.EventQuery($query))
    while ($true) {
        $ev = $watcher.WaitForNextEvent()
        $line = "$(Get-Date -Format 's') - Firewall rule modified: $($ev.TargetInstance.DisplayName)"
        Add-Content -Path $changeLog -Value $line
        Write-Host $line -ForegroundColor Yellow
    }
}

if ($PSCmdlet.ShouldProcess('mpssvc', 'Enable Windows Firewall & logging on all profiles')) {
    Start-Service -Name mpssvc -ErrorAction SilentlyContinue
    Set-Service -Name mpssvc -StartupType Automatic -ErrorAction SilentlyContinue
    Set-NetFirewallProfile -Profile Domain,Private,Public -Enabled True -LogFileName $fwLog -LogMaxSizeKilobytes 20480 -LogAllowed True -LogBlocked True
    Write-Host "[+] Firewall enabled across Domain/Private/Public. Log: $fwLog" -ForegroundColor Green
}

# Always ensure RDP (3389) and SSH (22) remain open
foreach ($mgmt in @(@('CCDC-Allow-RDP', 3389), @('CCDC-Allow-SSH', 22))) {
    $ruleName, $port = $mgmt[0], $mgmt[1]
    if (-not (Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue)) {
        if ($PSCmdlet.ShouldProcess($ruleName, "Allow Inbound TCP $port")) {
            New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Action Allow -Protocol TCP -LocalPort $port -Profile Any -Enabled True | Out-Null
            Write-Host "[+] Created rule: $ruleName (TCP $port)" -ForegroundColor Green
        }
    }
}

# Allow explicit scored ports
foreach ($port in $AllowPorts) {
    $ruleName = "CCDC-Allow-TCP-$port"
    if (-not (Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue)) {
        if ($PSCmdlet.ShouldProcess($ruleName, "Allow Inbound TCP $port")) {
            New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Action Allow -Protocol TCP -LocalPort $port -Profile Any -Enabled True | Out-Null
            Write-Host "[+] Allowed Inbound TCP $port" -ForegroundColor Green
        }
    }
}

if ($Interactive) {
    $portsInput = Read-Host 'Enter comma-separated TCP ports to allow inbound (or press Enter to skip)'
    if ($portsInput -match '\d') {
        foreach ($p in ($portsInput -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^\d+$' })) {
            $rn = "CCDC-Allow-TCP-$p"
            if ($PSCmdlet.ShouldProcess($rn, "Allow Inbound TCP $p")) {
                New-NetFirewallRule -DisplayName $rn -Direction Inbound -Action Allow -Protocol TCP -LocalPort ([int]$p) -Profile Any -Enabled True -ErrorAction SilentlyContinue | Out-Null
                Write-Host "[+] Allowed Inbound TCP $p" -ForegroundColor Green
            }
        }
    }
}

if ($AddImplicitDeny) {
    Write-Warning 'Adding inbound DefaultInboundAction=Block across all profiles (explicit Allow rules remain active).'
    if ($PSCmdlet.ShouldProcess('NetFirewallProfile', 'Set DefaultInboundAction Block')) {
        Set-NetFirewallProfile -Profile Domain,Private,Public -DefaultInboundAction Block
        Write-Host '[+] DefaultInboundAction set to Block.' -ForegroundColor Green
    }
}
