<#
.SYNOPSIS
    CCDC Windows Firewall builder, logging enabler, and rule-change monitor (Create/Modify/Delete).

.DESCRIPTION
    Replaces ptb/dawall.ps1. Clears firewall-disable policy overrides, enables Windows Firewall
    (mpssvc) and logging across Domain/Private/Public profiles, preserves RDP (3389) and SSH (22),
    allows TCP/UDP ports (automatically opens both TCP and UDP for port 53 DNS, plus -AllowUdpPorts),
    and monitors rule creation, modification, and deletion via __InstanceOperationEvent.

.EXAMPLE
    .\8-FirewallBuilder.ps1 -AllowPorts 80,443,53
    .\8-FirewallBuilder.ps1 -AllowPorts 80,443 -AllowUdpPorts 53,123
    .\8-FirewallBuilder.ps1 -Interactive
    .\8-FirewallBuilder.ps1 -AllowPorts 80,443,53 -AddImplicitDeny
    .\8-FirewallBuilder.ps1 -Monitor
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [int[]]$AllowPorts = @(),
    [int[]]$AllowUdpPorts = @(),
    [switch]$Interactive,
    [switch]$AddImplicitDeny,
    [switch]$Monitor,
    [string]$LogDir = 'C:\tools\logs'
)

$ErrorActionPreference = 'Continue'

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run 8-FirewallBuilder.ps1 from an elevated (Administrator) PowerShell session.'
}

if (-not (Test-Path $LogDir)) {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
}
$fwLog = Join-Path $LogDir 'pfirewall.log'
$changeLog = Join-Path $LogDir 'FirewallChanges.log'

if ($Monitor) {
    Write-Host "[*] Monitoring Windows Firewall rule Create/Modify/Delete -> $changeLog (Ctrl+C to stop)..." -ForegroundColor Cyan
    $query = "SELECT * FROM __InstanceOperationEvent WITHIN 5 WHERE TargetInstance ISA 'MSFT_NetFirewallRule'"
    $watcher = New-Object Management.ManagementEventWatcher (New-Object Management.ManagementScope('\\.\root\StandardCimv2')), (New-Object Management.EventQuery($query))
    while ($true) {
        $ev = $watcher.WaitForNextEvent()
        $evtType = switch ($ev.__CLASS) {
            '__InstanceCreationEvent'     { 'CREATED' }
            '__InstanceModificationEvent' { 'MODIFIED' }
            '__InstanceDeletionEvent'     { 'DELETED' }
            default                       { $ev.__CLASS }
        }
        $rule = $ev.TargetInstance
        $line = "$(Get-Date -Format 's') [$evtType] $($rule.DisplayName) (Direction=$($rule.Direction), Action=$($rule.Action), Enabled=$($rule.Enabled))"
        Add-Content -Path $changeLog -Value $line
        $color = if ($evtType -eq 'DELETED') { 'Red' } elseif ($evtType -eq 'CREATED') { 'Yellow' } else { 'Cyan' }
        Write-Host $line -ForegroundColor $color
    }
}

# Clear any policy registry keys forcing Windows Firewall off
foreach ($fwProf in @('DomainProfile', 'StandardProfile', 'PublicProfile')) {
    $fwPol = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\$fwProf"
    if (Test-Path $fwPol) {
        if ((Get-ItemProperty -Path $fwPol -Name 'EnableFirewall' -ErrorAction SilentlyContinue).EnableFirewall -eq 0) {
            if ($PSCmdlet.ShouldProcess($fwPol, 'Set EnableFirewall = 1')) {
                Set-ItemProperty -Path $fwPol -Name 'EnableFirewall' -Value 1 -Force -ErrorAction SilentlyContinue
            }
        }
    }
}

if ($PSCmdlet.ShouldProcess('mpssvc', 'Enable Windows Firewall & logging on Domain, Private, Public profiles')) {
    Start-Service -Name mpssvc -ErrorAction SilentlyContinue
    Set-Service -Name mpssvc -StartupType Automatic -ErrorAction SilentlyContinue
    Set-NetFirewallProfile -Profile Domain,Private,Public -Enabled True -LogFileName $fwLog -LogMaxSizeKilobytes 20480 -LogAllowed True -LogBlocked True
    Write-Host "[+] Firewall enabled across Domain/Private/Public. Log: $fwLog" -ForegroundColor Green
}

function Ensure-AllowRule {
    param([int]$Port, [ValidateSet('TCP', 'UDP')][string]$Protocol, [string]$CustomName)
    $ruleName = if ($CustomName) { $CustomName } else { "CCDC-Allow-$Protocol-$Port" }
    if (-not (Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue)) {
        if ($PSCmdlet.ShouldProcess($ruleName, "Allow Inbound $Protocol $Port")) {
            New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Action Allow -Protocol $Protocol -LocalPort $Port -Profile Any -Enabled True | Out-Null
            Write-Host "[+] Allowed Inbound $Protocol $Port ($ruleName)" -ForegroundColor Green
        }
    }
}

# Always ensure RDP (3389) and SSH (22) remain open
Ensure-AllowRule -Port 3389 -Protocol TCP -CustomName 'CCDC-Allow-RDP'
Ensure-AllowRule -Port 22   -Protocol TCP -CustomName 'CCDC-Allow-SSH'

# Common dual/UDP service ports: if passed in -AllowPorts, also open UDP automatically
$autoUdpPorts = @(53, 67, 68, 123, 161, 162, 514)

foreach ($port in $AllowPorts) {
    Ensure-AllowRule -Port $port -Protocol TCP
    if ($autoUdpPorts -contains $port) {
        Ensure-AllowRule -Port $port -Protocol UDP
    }
}

foreach ($port in $AllowUdpPorts) {
    Ensure-AllowRule -Port $port -Protocol UDP
}

if ($Interactive) {
    $portsInput = Read-Host 'Enter comma-separated ports to allow (e.g. 80,443,53 or 123/udp; Enter to skip)'
    if ($portsInput -match '\d') {
        foreach ($entry in ($portsInput -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })) {
            if ($entry -match '^(\d+)/(tcp|udp|both)$') {
                $p = [int]$matches[1]
                $proto = $matches[2].ToUpper()
                if ($proto -eq 'BOTH') {
                    Ensure-AllowRule -Port $p -Protocol TCP
                    Ensure-AllowRule -Port $p -Protocol UDP
                } else {
                    Ensure-AllowRule -Port $p -Protocol $proto
                }
            } elseif ($entry -match '^\d+$') {
                $p = [int]$entry
                Ensure-AllowRule -Port $p -Protocol TCP
                if ($autoUdpPorts -contains $p) {
                    Ensure-AllowRule -Port $p -Protocol UDP
                }
            }
        }
    }
}

if ($AddImplicitDeny) {
    Write-Warning 'Adding inbound DefaultInboundAction=Block across all profiles (explicit Allow rules remain active).'
    if ($PSCmdlet.ShouldProcess('NetFirewallProfile', 'Set DefaultInboundAction Block')) {
        Set-NetFirewallProfile -Profile Domain,Private,Public -DefaultInboundAction Block
        Write-Host '[+] DefaultInboundAction set to Block.' -ForegroundColor Green
    }
}
