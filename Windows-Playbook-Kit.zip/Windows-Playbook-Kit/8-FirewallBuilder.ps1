<#
.SYNOPSIS
    CCDC Windows Firewall builder, logging enabler, rule-change monitor, and 5-minute RDP/SSH/Firewall watchdog.

.DESCRIPTION
    Replaces ptb/dawall.ps1. Clears firewall-disable policy overrides, enables Windows Firewall
    (mpssvc) and logging across Domain/Private/Public profiles, preserves RDP (3389) and SSH (22),
    auto-opens AD/DNS ports on DCs and 80/443 when IIS (W3SVC) is present, allows custom TCP/UDP ports,
    monitors rule Create/Modify/Delete (-Monitor), and can run a continuous watchdog (-Watchdog) every
    5 minutes (300s) to re-enable Firewall profiles, RDP, SSH, and scored port rules if turned off.

.EXAMPLE
    .\8-FirewallBuilder.ps1 -AllowPorts 80,443,53
    .\8-FirewallBuilder.ps1 -AllowPorts 80,443 -Watchdog -Background
    .\8-FirewallBuilder.ps1 -Monitor
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [int[]]$AllowPorts = @(),
    [int[]]$AllowUdpPorts = @(),
    [switch]$Interactive,
    [switch]$AddImplicitDeny,
    [switch]$Monitor,
    [switch]$Watchdog,
    [int]$IntervalSeconds = 300,
    [switch]$Background,
    [string]$LogDir = 'C:\tools\logs'
)

$ErrorActionPreference = 'Continue'

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run 8-FirewallBuilder.ps1 from an elevated (Administrator) PowerShell session.'
}

if (-not (Test-Path $LogDir)) {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
}
$fwLog = Join-Path $LogDir 'pfirewall.log'
$changeLog = Join-Path $LogDir 'FirewallChanges.log'
$wdLog = Join-Path $LogDir 'FirewallWatchdog.log'

if ($Monitor) {
    Write-Host "[*] Monitoring Windows Firewall rule Create/Modify/Delete -> $changeLog (Ctrl+C to stop)..." -ForegroundColor Cyan
    $query = "SELECT * FROM __InstanceOperationEvent WITHIN 5 WHERE TargetInstance ISA 'MSFT_NetFirewallRule'"
    $watcher = New-Object Management.ManagementEventWatcher (New-Object Management.ManagementScope('\\.\root\StandardCimv2')), (New-Object Management.EventQuery($query))
    while ($true) {
        $ev = $watcher.WaitForNextEvent()
        $evtType = switch ($ev.__CLASS) {
            '__InstanceCreationEvent'     { 'CREATED' }
            '__InstanceModificationEvent' { 'MODIFIED' }
            '__InstanceDeletionEvent'     { 'DELETED' }
            default                       { $ev.__CLASS }
        }
        $rule = $ev.TargetInstance
        $line = "$(Get-Date -Format 's') [$evtType] $($rule.DisplayName) (Direction=$($rule.Direction), Action=$($rule.Action), Enabled=$($rule.Enabled))"
        Add-Content -Path $changeLog -Value $line
        $color = if ($evtType -eq 'DELETED') { 'Red' } elseif ($evtType -eq 'CREATED') { 'Yellow' } else { 'Cyan' }
        Write-Host $line -ForegroundColor $color
    }
}

function Ensure-FirewallAndPorts {
    param([int[]]$TcpPorts, [int[]]$UdpPorts, [string]$LogFile, [bool]$Quiet = $false)

    foreach ($fwProf in @('DomainProfile', 'StandardProfile', 'PublicProfile')) {
        $fwPol = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\$fwProf"
        if (Test-Path $fwPol) {
            if ((Get-ItemProperty -Path $fwPol -Name 'EnableFirewall' -ErrorAction SilentlyContinue).EnableFirewall -eq 0) {
                Set-ItemProperty -Path $fwPol -Name 'EnableFirewall' -Value 1 -Force -ErrorAction SilentlyContinue
            }
        }
    }

    $mps = Get-Service -Name mpssvc -ErrorAction SilentlyContinue
    if ($mps -and $mps.Status -ne 'Running') {
        Set-Service -Name mpssvc -StartupType Automatic -ErrorAction SilentlyContinue
        Start-Service -Name mpssvc -ErrorAction SilentlyContinue
        if ($Quiet) { Add-Content -Path $wdLog -Value "$(Get-Date -Format 's') [ALERT] mpssvc was stopped - restarted." }
    }

    $offProfiles = Get-NetFirewallProfile -ErrorAction SilentlyContinue | Where-Object { -not $_.Enabled }
    if ($offProfiles -or -not $Quiet) {
        Set-NetFirewallProfile -Profile Domain,Private,Public -Enabled True -LogFileName $LogFile -LogMaxSizeKilobytes 20480 -LogAllowed True -LogBlocked True -ErrorAction SilentlyContinue
        if ($offProfiles -and $Quiet) {
            Add-Content -Path $wdLog -Value "$(Get-Date -Format 's') [ALERT] Re-enabled disabled firewall profile(s): $($offProfiles.Name -join ', ')"
        }
    }

    # Ensure RDP (registry + TermService + rule)
    $tsPath = 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server'
    if ((Get-ItemProperty -Path $tsPath -Name 'fDenyTSConnections' -ErrorAction SilentlyContinue).fDenyTSConnections -ne 0) {
        Set-ItemProperty -Path $tsPath -Name 'fDenyTSConnections' -Value 0 -Force -ErrorAction SilentlyContinue
        if ($Quiet) { Add-Content -Path $wdLog -Value "$(Get-Date -Format 's') [ALERT] Re-enabled RDP (fDenyTSConnections=0)." }
    }
    $term = Get-Service -Name TermService -ErrorAction SilentlyContinue
    if ($term -and $term.Status -ne 'Running') {
        Set-Service -Name TermService -StartupType Automatic -ErrorAction SilentlyContinue
        Start-Service -Name TermService -ErrorAction SilentlyContinue
        if ($Quiet) { Add-Content -Path $wdLog -Value "$(Get-Date -Format 's') [ALERT] Restarted TermService (RDP)." }
    }

    # Ensure SSH (if installed)
    $sshd = Get-Service -Name sshd -ErrorAction SilentlyContinue
    if ($sshd -and $sshd.Status -ne 'Running') {
        Set-Service -Name sshd -StartupType Automatic -ErrorAction SilentlyContinue
        Start-Service -Name sshd -ErrorAction SilentlyContinue
        if ($Quiet) { Add-Content -Path $wdLog -Value "$(Get-Date -Format 's') [ALERT] Restarted sshd (SSH)." }
    }

    function Ensure-Rule {
        param([int]$Port, [string]$Proto, [string]$CustomName)
        $rn = if ($CustomName) { $CustomName } else { "CCDC-Allow-$Proto-$Port" }
        $existing = Get-NetFirewallRule -DisplayName $rn -ErrorAction SilentlyContinue | Select-Object -First 1
        if (-not $existing) {
            New-NetFirewallRule -DisplayName $rn -Direction Inbound -Action Allow -Protocol $Proto -LocalPort $Port -Profile Any -Enabled True -ErrorAction SilentlyContinue | Out-Null
            if ($Quiet) { Add-Content -Path $wdLog -Value "$(Get-Date -Format 's') [ALERT] Recreated missing rule: $rn" }
            else { Write-Host "[+] Allowed Inbound $Proto $Port ($rn)" -ForegroundColor Green }
        } elseif ($existing.Enabled -ne 'True' -or $existing.Action -ne 'Allow') {
            Set-NetFirewallRule -DisplayName $rn -Enabled True -Action Allow -ErrorAction SilentlyContinue
            if ($Quiet) { Add-Content -Path $wdLog -Value "$(Get-Date -Format 's') [ALERT] Repaired disabled/blocked rule: $rn" }
        }
    }

    Ensure-Rule -Port 3389 -Proto 'TCP' -CustomName 'CCDC-Allow-RDP'
    Ensure-Rule -Port 22   -Proto 'TCP' -CustomName 'CCDC-Allow-SSH'

    $role = (Get-CimInstance Win32_ComputerSystem).DomainRole
    if ($role -in 4, 5) {
        foreach ($p in @(53, 88, 135, 389, 445, 464, 636, 3268, 3269)) { Ensure-Rule -Port $p -Proto 'TCP' }
        foreach ($p in @(53, 88, 123, 389, 464)) { Ensure-Rule -Port $p -Proto 'UDP' }
    }
    if (Get-Service -Name 'W3SVC' -ErrorAction SilentlyContinue) {
        Ensure-Rule -Port 80  -Proto 'TCP'
        Ensure-Rule -Port 443 -Proto 'TCP'
    }

    $autoUdp = @(53, 67, 68, 123, 161, 162, 514)
    foreach ($p in $TcpPorts) {
        Ensure-Rule -Port $p -Proto 'TCP'
        if ($autoUdp -contains $p) { Ensure-Rule -Port $p -Proto 'UDP' }
    }
    foreach ($p in $UdpPorts) {
        Ensure-Rule -Port $p -Proto 'UDP'
    }
}

if ($PSCmdlet.ShouldProcess('Windows Firewall', 'Enable all 3 profiles, logging, RDP/SSH, and allowed ports')) {
    Ensure-FirewallAndPorts -TcpPorts $AllowPorts -UdpPorts $AllowUdpPorts -LogFile $fwLog -Quiet:$false
    Write-Host "[+] Firewall enabled across Domain/Private/Public. Log: $fwLog" -ForegroundColor Green
}

if ($Interactive) {
    $portsInput = Read-Host 'Enter comma-separated ports to allow (e.g. 80,443,53 or 123/udp; Enter to skip)'
    if ($portsInput -match '\d') {
        $extraTcp = @(); $extraUdp = @()
        foreach ($entry in ($portsInput -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })) {
            if ($entry -match '^(\d+)/udp$') { $extraUdp += [int]$matches[1] }
            elseif ($entry -match '^(\d+)/both$') { $extraTcp += [int]$matches[1]; $extraUdp += [int]$matches[1] }
            elseif ($entry -match '^(\d+)(/tcp)?$') { $extraTcp += [int]$matches[1] }
        }
        Ensure-FirewallAndPorts -TcpPorts $extraTcp -UdpPorts $extraUdp -LogFile $fwLog -Quiet:$false
    }
}

if ($AddImplicitDeny) {
    Write-Warning 'Adding inbound DefaultInboundAction=Block across all profiles (explicit Allow rules remain active).'
    if ($PSCmdlet.ShouldProcess('NetFirewallProfile', 'Set DefaultInboundAction Block')) {
        Set-NetFirewallProfile -Profile Domain,Private,Public -DefaultInboundAction Block
        Write-Host '[+] DefaultInboundAction set to Block.' -ForegroundColor Green
    }
}

if ($Watchdog) {
    $wdBlock = {
        param($FnDef, $TcpP, $UdpP, $FwLogPath, $WdLogPath, $Interval)
        Invoke-Expression $FnDef
        while ($true) {
            Start-Sleep -Seconds $Interval
            Ensure-FirewallAndPorts -TcpPorts $TcpP -UdpPorts $UdpP -LogFile $FwLogPath -Quiet:$true
        }
    }
    $fnText = "function Ensure-FirewallAndPorts { ${function:Ensure-FirewallAndPorts} }"
    if ($Background) {
        $job = Start-Job -Name 'CCDC-FirewallWatchdog' -ScriptBlock $wdBlock -ArgumentList $fnText, $AllowPorts, $AllowUdpPorts, $fwLog, $wdLog, $IntervalSeconds
        Write-Host "[+] FirewallWatchdog started in background every ${IntervalSeconds}s (Job ID $($job.Id)). Log: $wdLog" -ForegroundColor Green
    } else {
        Write-Host "[*] FirewallWatchdog running every ${IntervalSeconds}s (Ctrl+C to stop)..." -ForegroundColor Cyan
        & $wdBlock $fnText $AllowPorts $AllowUdpPorts $fwLog $wdLog $IntervalSeconds
    }
}
