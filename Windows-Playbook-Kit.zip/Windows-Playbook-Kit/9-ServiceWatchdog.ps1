<#
.SYNOPSIS
    CCDC Service Watchdog that monitors and auto-restarts critical/scored Windows services.

.DESCRIPTION
    Replaces ptb/servthis.ps1. Auto-detects DC vs Workstation baseline services and
    accepts additional scored service names via -Services. Runs in foreground or as
    a background PowerShell job (-Background).

.EXAMPLE
    .\9-ServiceWatchdog.ps1
    .\9-ServiceWatchdog.ps1 -Services W3SVC,MSSQLSERVER -Background
    .\9-ServiceWatchdog.ps1 -IntervalSeconds 10
#>
[CmdletBinding()]
param(
    [string[]]$Services = @(),
    [int]$IntervalSeconds = 15,
    [switch]$Background,
    [string]$LogDir = 'C:\tools\logs'
)

$ErrorActionPreference = 'SilentlyContinue'

if (-not (Test-Path $LogDir)) {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
}
$logPath = Join-Path $LogDir 'ServiceWatchdog.log'

$role = (Get-CimInstance Win32_ComputerSystem).DomainRole
$isDC = $role -in 4, 5

$watchList = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
foreach ($s in @('WinDefend', 'mpssvc', 'EventLog', 'TermService', 'Netlogon', 'Dnscache', 'W32Time')) {
    if (Get-Service -Name $s -ErrorAction SilentlyContinue) { [void]$watchList.Add($s) }
}
if ($isDC) {
    foreach ($s in @('NTDS', 'DNS', 'kdc', 'ADWS', 'DFSR')) {
        if (Get-Service -Name $s -ErrorAction SilentlyContinue) { [void]$watchList.Add($s) }
    }
}
foreach ($s in $Services) {
    foreach ($part in ($s -split ',')) {
        $t = $part.Trim()
        if ($t) { [void]$watchList.Add($t) }
    }
}

$targets = @($watchList)
Write-Host "[*] Watching $($targets.Count) services every ${IntervalSeconds}s: $($targets -join ', ')" -ForegroundColor Cyan

$watchBlock = {
    param($ServiceNames, $Interval, $LogFile)
    while ($true) {
        foreach ($name in $ServiceNames) {
            $svc = Get-Service -Name $name -ErrorAction SilentlyContinue
            if ($svc -and $svc.Status -ne 'Running') {
                $msg = "$(Get-Date -Format 's') [ALERT] $name was $($svc.Status) — restarting..."
                Add-Content -Path $LogFile -Value $msg
                Write-Host $msg -ForegroundColor Yellow
                Set-Service -Name $name -StartupType Automatic -ErrorAction SilentlyContinue
                Start-Service -Name $name -ErrorAction SilentlyContinue
            }
        }
        Start-Sleep -Seconds $Interval
    }
}

if ($Background) {
    $job = Start-Job -Name 'CCDC-ServiceWatchdog' -ScriptBlock $watchBlock -ArgumentList $targets, $IntervalSeconds, $logPath
    Write-Host "[+] ServiceWatchdog started in background (Job ID $($job.Id)). Check with: Get-Job | Receive-Job" -ForegroundColor Green
} else {
    Write-Host '[*] Running in foreground (Ctrl+C to stop)...' -ForegroundColor DarkGray
    & $watchBlock $targets $IntervalSeconds $logPath
}
