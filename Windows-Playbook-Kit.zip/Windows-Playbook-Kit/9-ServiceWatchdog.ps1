<#
.SYNOPSIS
    CCDC Service Watchdog monitoring RDP, SSH, and core Windows Server / DC / Workstation services with -Exempt support.

.DESCRIPTION
    Monitors RDP (TermService, UmRdpService, SessionEnv), SSH (sshd), and confirmed core Windows
    Server / AD / Workstation services that are installed and not Disabled on this host.
    Services listed in -Exempt are still monitored but NOT auto-restarted; if an exempt service is
    stopped, it reports/logs an alert once every 5 minutes (-ExemptAlertIntervalSeconds 300).

.EXAMPLE
    .\9-ServiceWatchdog.ps1
    .\9-ServiceWatchdog.ps1 -Background
    .\9-ServiceWatchdog.ps1 -Exempt W3SVC,sshd -Background
    .\9-ServiceWatchdog.ps1 -Services MyCustomApp -Exempt Spooler
#>
[CmdletBinding()]
param(
    [string[]]$Services = @(),
    [string[]]$Exempt = @(),
    [int]$IntervalSeconds = 15,
    [int]$ExemptAlertIntervalSeconds = 300,
    [switch]$Background,
    [string]$LogDir = 'C:\tools\logs'
)

$ErrorActionPreference = 'SilentlyContinue'

if (-not (Test-Path $LogDir)) {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
}
$logPath = Join-Path $LogDir 'ServiceWatchdog.log'

$role = (Get-CimInstance Win32_ComputerSystem).DomainRole
$isDC = $role -in 4, 5

# Confirmed core Windows Server / Workstation / Security / Remote / App services (~100 services)
$confirmedServices = @(
    # Remote Access (RDP + SSH) & Security
    'TermService', 'UmRdpService', 'SessionEnv', 'sshd', 'ssh-agent',
    'WinDefend', 'WdNisSvc', 'mpssvc', 'BFE', 'EventLog', 'wscsvc', 'fibratus', 'Sysmon64', 'Sysmon',
    # Core OS & Networking
    'Dhcp', 'Dnscache', 'NlaSvc', 'netprofm', 'Netman', 'nsi', 'iphlpsvc', 'lmhosts',
    'LanmanServer', 'LanmanWorkstation', 'Netlogon', 'W32Time', 'gpsvc', 'PolicyAgent', 'IKEEXT',
    'RpcSs', 'RpcEptMapper', 'DcomLaunch', 'LSM', 'SamSs', 'Schedule', 'ProfSvc', 'UserManager',
    'CryptSvc', 'KeyIso', 'VaultSvc', 'CNGKeyIsolation', 'TokenBroker', 'CertPropSvc',
    'BrokerInfrastructure', 'CoreMessagingRegistrar', 'SystemEventsBroker', 'TimeBrokerSvc', 'StateRepository',
    'EventSystem', 'SENS', 'Power', 'PlugPlay', 'ShellHWDetection', 'Themes', 'FontCache',
    'COMSysApp', 'MSDTC', 'Appinfo', 'AppIDSvc', 'AppMgmt', 'AppReadiness', 'AppXSvc', 'ClipSVC',
    'BITS', 'DoSvc', 'UsoSvc', 'wuauserv', 'TrustedInstaller', 'msiserver', 'InstallService',
    'Winmgmt', 'WMIApSrv', 'WinHttpAutoProxySvc', 'WinRM', 'TrkWks', 'SysMain', 'StorSvc', 'vds', 'VSS',
    'swprv', 'defragsvc', 'DPS', 'WdiServiceHost', 'WdiSystemHost', 'PcaSvc', 'NcbService', 'NcdAutoSetup',
    'CDPSvc', 'CDPUserSvc', 'Wcmsvc', 'WpnService', 'WSearch', 'seclogon', 'AudioEndpointBuilder', 'Audiosrv',
    'TabletInputService', 'DispBrokerDesktopSvc', 'DeviceAssociationService', 'DeviceInstall', 'LicenseManager',
    # Common Scored Server Roles (auto-monitored only if installed & not Disabled)
    'W3SVC', 'WAS', 'AppHostSvc', 'IISAdmin', 'FTPSVC', 'MSSQLSERVER', 'SQLSERVERAGENT', 'SNMP', 'TSGateway'
)

$dcServices = @('NTDS', 'DNS', 'kdc', 'ADWS', 'DFSR', 'Dfs', 'IsmServ', 'DHCPServer', 'CertSvc')

# Build exempt set
$exemptSet = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
foreach ($e in $Exempt) {
    foreach ($part in ($e -split ',')) {
        $t = $part.Trim()
        if ($t) { [void]$exemptSet.Add($t) }
    }
}

$watchList = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
$candidateList = @($confirmedServices)
if ($isDC) { $candidateList += $dcServices }

# Only watch confirmed services that exist on this host and are currently Running or set to Auto (never fight intentionally Disabled services)
$allWmiSvcs = @{}
Get-CimInstance Win32_Service -ErrorAction SilentlyContinue | ForEach-Object { $allWmiSvcs[$_.Name] = $_ }

foreach ($name in $candidateList) {
    if ($allWmiSvcs.ContainsKey($name)) {
        $svcObj = $allWmiSvcs[$name]
        if ($svcObj.State -eq 'Running' -or $svcObj.StartMode -eq 'Auto' -or $exemptSet.Contains($name)) {
            [void]$watchList.Add($name)
        }
    }
}

# Always add explicitly requested -Services and -Exempt services if installed
foreach ($s in ($Services + $Exempt)) {
    foreach ($part in ($s -split ',')) {
        $t = $part.Trim()
        if ($t -and $allWmiSvcs.ContainsKey($t)) { [void]$watchList.Add($t) }
    }
}

$targets = @($watchList)
$exemptArr = @($exemptSet)
Write-Host "[*] Watching $($targets.Count) active services every ${IntervalSeconds}s (Exempt monitor-only every ${ExemptAlertIntervalSeconds}s: $(if ($exemptArr.Count -gt 0) { $exemptArr -join ', ' } else { 'None' }))" -ForegroundColor Cyan

$watchBlock = {
    param($ServiceNames, $ExemptNames, $Interval, $ExemptInterval, $LogFile)
    $exemptLookup = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($x in $ExemptNames) { [void]$exemptLookup.Add($x) }
    $lastExemptAlert = @{}

    while ($true) {
        $now = Get-Date
        foreach ($name in $ServiceNames) {
            $svc = Get-Service -Name $name -ErrorAction SilentlyContinue
            if ($svc -and $svc.Status -ne 'Running') {
                if ($exemptLookup.Contains($name)) {
                    $shouldAlert = (-not $lastExemptAlert.ContainsKey($name)) -or (($now - $lastExemptAlert[$name]).TotalSeconds -ge $ExemptInterval)
                    if ($shouldAlert) {
                        $msg = "$(Get-Date -Format 's') [EXEMPT-OFF] $name is $($svc.Status) (not auto-restarting; next check in ${ExemptInterval}s)"
                        Add-Content -Path $LogFile -Value $msg
                        Write-Host $msg -ForegroundColor Magenta
                        $lastExemptAlert[$name] = $now
                    }
                } else {
                    $msg = "$(Get-Date -Format 's') [ALERT] $name was $($svc.Status) - restarting..."
                    Add-Content -Path $LogFile -Value $msg
                    Write-Host $msg -ForegroundColor Yellow
                    Set-Service -Name $name -StartupType Automatic -ErrorAction SilentlyContinue
                    Start-Service -Name $name -ErrorAction SilentlyContinue
                }
            } elseif ($svc -and $svc.Status -eq 'Running' -and $lastExemptAlert.ContainsKey($name)) {
                $lastExemptAlert.Remove($name)
            }
        }
        Start-Sleep -Seconds $Interval
    }
}

if ($Background) {
    $job = Start-Job -Name 'CCDC-ServiceWatchdog' -ScriptBlock $watchBlock -ArgumentList $targets, $exemptArr, $IntervalSeconds, $ExemptAlertIntervalSeconds, $logPath
    Write-Host "[+] ServiceWatchdog started in background (Job ID $($job.Id)). Check with: Get-Job | Receive-Job" -ForegroundColor Green
} else {
    Write-Host '[*] Running in foreground (Ctrl+C to stop)...' -ForegroundColor DarkGray
    & $watchBlock $targets $exemptArr $IntervalSeconds $ExemptAlertIntervalSeconds $logPath
}
