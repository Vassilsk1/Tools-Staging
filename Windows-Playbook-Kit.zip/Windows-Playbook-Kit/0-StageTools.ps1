<#
.SYNOPSIS
    All-in-one CCDC tool stager: Vassilsk1/Tools.git, Hayabusa, Fibratus, NetLimiter, Everything, Sysinternals, and System Informer.

.DESCRIPTION
    Creates C:\tools\{logs,scripts,bins,zips}, adds a Defender exclusion for C:\tools, and downloads
    in order:
      1. Vassilsk1/Tools.git -> C:\tools\bins\Tools (git --depth 1 with ZIP fallback)
      2. Hayabusa v4.4.0     -> C:\tools\bins\hayabusa
      3. Fibratus (MSI)      -> C:\tools\zips\fibratus-setup.msi
      4. NetLimiter 4        -> C:\tools\bins\netlimiter.exe
      5. Everything (x64)    -> C:\tools\bins\Everything
      6. Sysinternals Suite  -> C:\tools\bins\SysinternalsSuite
      7. System Informer     -> C:\tools\bins\systeminformer-setup.exe

.EXAMPLE
    .\0-StageTools.ps1
    .\0-StageTools.ps1 -CreateDirsOnly
    .\0-StageTools.ps1 -ForceRedownload
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$BaseDir = 'C:\tools',
    [string]$RepoUrl = 'https://github.com/Vassilsk1/Tools.git',
    [string]$HayabusaUrl = 'https://github.com/Yamato-Security/hayabusa/releases/download/v4.4.0/hayabusa-4.4.0-win-x64-live-response.zip',
    [switch]$CreateDirsOnly,
    [switch]$ForceRedownload
)

$ErrorActionPreference = 'Continue'

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run 0-StageTools.ps1 from an elevated (Administrator) PowerShell session.'
}

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$zipsDir = Join-Path $BaseDir 'zips'
$binsDir = Join-Path $BaseDir 'bins'
$dirs = @($BaseDir, (Join-Path $BaseDir 'logs'), (Join-Path $BaseDir 'scripts'), $binsDir, $zipsDir)

foreach ($dir in $dirs) {
    if (-not (Test-Path $dir)) {
        if ($PSCmdlet.ShouldProcess($dir, 'Create directory')) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
            Write-Host "[+] Created $dir" -ForegroundColor Green
        }
    }
}

try {
    $mp = Get-MpPreference -ErrorAction SilentlyContinue
    if ($mp -and ($mp.ExclusionPath -notcontains $BaseDir)) {
        if ($PSCmdlet.ShouldProcess($BaseDir, 'Add Defender exclusion for C:\tools')) {
            Add-MpPreference -ExclusionPath $BaseDir -ErrorAction SilentlyContinue
            Write-Host "[+] Added Defender exclusion for $BaseDir" -ForegroundColor Cyan
        }
    }
} catch {
    Write-Warning "Could not configure Defender exclusion for ${BaseDir}: $($_.Exception.Message)"
}

if ($CreateDirsOnly) {
    Write-Host '[*] Directory staging complete (-CreateDirsOnly).' -ForegroundColor Cyan
    return
}

function Invoke-SafeDownload {
    param([string]$Uri, [string]$OutFile, [string]$Label)
    if ((Test-Path $OutFile) -and -not $ForceRedownload) {
        Write-Host "[=] $Label already exists at $OutFile" -ForegroundColor DarkGray
        return $true
    }
    if ($PSCmdlet.ShouldProcess($OutFile, "Download $Label")) {
        Write-Host "[*] Downloading $Label..." -ForegroundColor Cyan
        try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor 12288 } catch {}
        if (Get-Command curl.exe -ErrorAction SilentlyContinue) {
            & curl.exe -fSL --ssl-no-revoke --connect-timeout 30 --max-time 180 -o $OutFile $Uri
            if ($LASTEXITCODE -eq 0 -and (Test-Path $OutFile) -and ((Get-Item $OutFile).Length -gt 1024)) {
                Write-Host "[+] Downloaded $Label -> $OutFile" -ForegroundColor Green
                return $true
            }
        }
        try {
            Invoke-WebRequest -Uri $Uri -OutFile $OutFile -UseBasicParsing -TimeoutSec 180
            Write-Host "[+] Downloaded $Label -> $OutFile" -ForegroundColor Green
            return $true
        } catch {
            Write-Warning "Failed to download ${Label}: $($_.Exception.Message)"
            return $false
        }
    }
    return $false
}

# --- 1. Vassilsk1/Tools.git ---
$toolsDest = Join-Path $binsDir 'Tools'
if ((Test-Path $toolsDest) -and $ForceRedownload) {
    if ($PSCmdlet.ShouldProcess($toolsDest, 'Remove existing Tools folder')) {
        Remove-Item -Path $toolsDest -Recurse -Force -ErrorAction SilentlyContinue
    }
}

$clonedOk = $false
$gitCmd = Get-Command git -ErrorAction SilentlyContinue
if ($gitCmd) {
    if (Test-Path (Join-Path $toolsDest '.git')) {
        if ($PSCmdlet.ShouldProcess($toolsDest, "git pull $RepoUrl")) {
            Write-Host "[*] Updating existing Tools repo in $toolsDest..." -ForegroundColor Cyan
            & git -C $toolsDest pull --ff-only
            if ($LASTEXITCODE -eq 0) { $clonedOk = $true; Write-Host "[+] Updated Tools -> $toolsDest" -ForegroundColor Green }
        }
    } else {
        if ($PSCmdlet.ShouldProcess($toolsDest, "git clone --depth 1 $RepoUrl")) {
            Write-Host "[*] Cloning $RepoUrl -> $toolsDest..." -ForegroundColor Cyan
            & git -c http.postBuffer=524288000 clone --depth 1 $RepoUrl $toolsDest
            if ($LASTEXITCODE -eq 0) {
                $clonedOk = $true
                Write-Host "[+] Cloned Tools -> $toolsDest" -ForegroundColor Green
            } else {
                Write-Warning 'git clone failed; falling back to GitHub ZIP...'
                if (Test-Path $toolsDest) { Remove-Item -Path $toolsDest -Recurse -Force -ErrorAction SilentlyContinue }
            }
        }
    }
}

if (-not $clonedOk -and -not $WhatIfPreference) {
    $repoBase = $RepoUrl -replace '\.git$', ''
    $zipPath  = Join-Path $zipsDir 'Tools.zip'
    foreach ($branch in @('main', 'master')) {
        if (Invoke-SafeDownload -Uri "$repoBase/archive/refs/heads/$branch.zip" -OutFile $zipPath -Label "Tools.git ($branch)") {
            $tmpExtract = Join-Path $zipsDir 'Tools_extract_tmp'
            if (Test-Path $tmpExtract) { Remove-Item -Path $tmpExtract -Recurse -Force }
            Expand-Archive -Path $zipPath -DestinationPath $tmpExtract -Force
            $inner = Get-ChildItem -Path $tmpExtract -Directory | Select-Object -First 1
            if ($inner) {
                if (Test-Path $toolsDest) { Remove-Item -Path $toolsDest -Recurse -Force }
                Move-Item -Path $inner.FullName -Destination $toolsDest -Force
            }
            Remove-Item -Path $tmpExtract -Recurse -Force -ErrorAction SilentlyContinue
            Write-Host "[+] Extracted Tools -> $toolsDest" -ForegroundColor Green
            break
        }
    }
}

# --- 2. Hayabusa v4.4.0 ---
$hayaZip = Join-Path $zipsDir 'hayabusa-4.4.0-win-x64-live-response.zip'
$hayaOut = Join-Path $binsDir 'hayabusa'
if ((Test-Path $hayaOut) -and -not $ForceRedownload) {
    Write-Host "[=] Hayabusa already exists at $hayaOut" -ForegroundColor DarkGray
} elseif (Invoke-SafeDownload -Uri $HayabusaUrl -OutFile $hayaZip -Label 'Hayabusa v4.4.0') {
    if ($PSCmdlet.ShouldProcess($hayaOut, 'Extract Hayabusa')) {
        if (Test-Path $hayaOut) { Remove-Item -Path $hayaOut -Recurse -Force }
        Expand-Archive -Path $hayaZip -DestinationPath $hayaOut -Force
        Write-Host "[+] Extracted Hayabusa -> $hayaOut" -ForegroundColor Green
    }
}

# --- 3. Fibratus MSI (Windows Server & Desktop EDR sensor) ---
$fibMsi = Join-Path $zipsDir 'fibratus-setup.msi'
if ((Test-Path $fibMsi) -and -not $ForceRedownload) {
    Write-Host "[=] Fibratus MSI already exists at $fibMsi" -ForegroundColor DarkGray
} else {
    try {
        $rel = Invoke-RestMethod -Uri 'https://api.github.com/repos/rabbitstack/fibratus/releases/latest' -UseBasicParsing -TimeoutSec 30
        $asset = $rel.assets | Where-Object { $_.name -like '*amd64*.msi' -or $_.name -like '*.msi' } | Select-Object -First 1
        if ($asset) {
            Invoke-SafeDownload -Uri $asset.browser_download_url -OutFile $fibMsi -Label "Fibratus ($($rel.tag_name))" | Out-Null
        }
    } catch {
        Write-Warning "Could not query Fibratus GitHub release: $($_.Exception.Message)"
    }
}

# --- 4. NetLimiter 4 ---
$nlExe = Join-Path $binsDir 'netlimiter.exe'
Invoke-SafeDownload -Uri 'https://www.netlimiter.com/files/download/nl4/netlimiter-4.1.14.0.exe' -OutFile $nlExe -Label 'NetLimiter 4' | Out-Null

# --- 5. Everything (voidtools x64 portable) ---
$evZip = Join-Path $zipsDir 'Everything-x64.zip'
$evOut = Join-Path $binsDir 'Everything'
if ((Test-Path $evOut) -and -not $ForceRedownload) {
    Write-Host "[=] Everything already exists at $evOut" -ForegroundColor DarkGray
} else {
    $evUrl = 'https://www.voidtools.com/Everything-1.4.1.1026.x64.zip'
    try {
        $page = Invoke-WebRequest -Uri 'https://www.voidtools.com/downloads/' -UseBasicParsing -TimeoutSec 20
        $m = [regex]::Match($page.Content, 'Everything-[0-9.]+\.x64\.zip')
        if ($m.Success) { $evUrl = "https://www.voidtools.com/$($m.Value)" }
    } catch {}
    if (Invoke-SafeDownload -Uri $evUrl -OutFile $evZip -Label 'Everything (x64)') {
        if ($PSCmdlet.ShouldProcess($evOut, 'Extract Everything')) {
            if (Test-Path $evOut) { Remove-Item -Path $evOut -Recurse -Force }
            Expand-Archive -Path $evZip -DestinationPath $evOut -Force
            Write-Host "[+] Extracted Everything -> $evOut" -ForegroundColor Green
        }
    }
}

# --- 6. Sysinternals Suite ---
$sysZip = Join-Path $zipsDir 'SysinternalsSuite.zip'
$sysOut = Join-Path $binsDir 'SysinternalsSuite'
if ((Test-Path $sysOut) -and -not $ForceRedownload) {
    Write-Host "[=] Sysinternals Suite already exists at $sysOut" -ForegroundColor DarkGray
} elseif (Invoke-SafeDownload -Uri 'https://download.sysinternals.com/files/SysinternalsSuite.zip' -OutFile $sysZip -Label 'Sysinternals Suite') {
    if ($PSCmdlet.ShouldProcess($sysOut, 'Extract Sysinternals Suite')) {
        Expand-Archive -Path $sysZip -DestinationPath $sysOut -Force
        Write-Host "[+] Extracted Sysinternals Suite -> $sysOut" -ForegroundColor Green
    }
}

# --- 7. System Informer ---
$siExe = Join-Path $binsDir 'systeminformer-setup.exe'
Invoke-SafeDownload -Uri 'https://sourceforge.net/projects/systeminformer/files/systeminformer-3.2.25011-release-setup.exe/download' -OutFile $siExe -Label 'System Informer' | Out-Null

Write-Host "`n[+] All tools staged in $BaseDir" -ForegroundColor Green
