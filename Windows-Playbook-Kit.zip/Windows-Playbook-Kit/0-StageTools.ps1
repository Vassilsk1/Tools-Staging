<#
.SYNOPSIS
    Stages CCDC Blue Team directories and downloads tools from https://github.com/Vassilsk1/Tools.git.

.DESCRIPTION
    Creates C:\tools\{logs,scripts,bins,zips}, adds a Windows Defender exclusion for C:\tools,
    and pulls https://github.com/Vassilsk1/Tools.git into C:\tools\bins\Tools.
    Uses git if installed, or automatically falls back to downloading and extracting the
    GitHub repository ZIP archive if git is not available on the host.

.EXAMPLE
    .\0-StageTools.ps1
    .\0-StageTools.ps1 -CreateDirsOnly
    .\0-StageTools.ps1 -ForceRedownload
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$BaseDir = 'C:\tools',
    [string]$RepoUrl = 'https://github.com/Vassilsk1/Tools.git',
    [switch]$CreateDirsOnly,
    [switch]$ForceRedownload
)

$ErrorActionPreference = 'Stop'

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run 0-StageTools.ps1 from an elevated (Administrator) PowerShell session.'
}

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$dirs = @(
    $BaseDir,
    (Join-Path $BaseDir 'logs'),
    (Join-Path $BaseDir 'scripts'),
    (Join-Path $BaseDir 'bins'),
    (Join-Path $BaseDir 'zips')
)

foreach ($dir in $dirs) {
    if (-not (Test-Path $dir)) {
        if ($PSCmdlet.ShouldProcess($dir, 'Create directory')) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
            Write-Host "[+] Created $dir" -ForegroundColor Green
        }
    }
}

# Add Defender exclusion for C:\tools so Blue Team scripts/tools are not quarantined
try {
    $mp = Get-MpPreference -ErrorAction SilentlyContinue
    if ($mp -and ($mp.ExclusionPath -notcontains $BaseDir)) {
        if ($PSCmdlet.ShouldProcess($BaseDir, 'Add Defender exclusion for C:\tools')) {
            Add-MpPreference -ExclusionPath $BaseDir -ErrorAction SilentlyContinue
            Write-Host "[+] Added Defender exclusion for $BaseDir" -ForegroundColor Cyan
        }
    }
} catch {
    Write-Warning "Could not configure Defender exclusion for ${BaseDir}: $($_.Exception.Message)"
}

if ($CreateDirsOnly) {
    Write-Host '[*] Directory staging complete (-CreateDirsOnly).' -ForegroundColor Cyan
    return
}

$toolsDest = Join-Path (Join-Path $BaseDir 'bins') 'Tools'
$zipsDir   = Join-Path $BaseDir 'zips'

if ((Test-Path $toolsDest) -and $ForceRedownload) {
    if ($PSCmdlet.ShouldProcess($toolsDest, 'Remove existing Tools folder for fresh download')) {
        Remove-Item -Path $toolsDest -Recurse -Force
    }
}

$gitCmd = Get-Command git -ErrorAction SilentlyContinue
if ($gitCmd) {
    if (Test-Path (Join-Path $toolsDest '.git')) {
        if ($PSCmdlet.ShouldProcess($toolsDest, "git pull $RepoUrl")) {
            Write-Host "[*] Updating existing Tools repo in $toolsDest..." -ForegroundColor Cyan
            & git -C $toolsDest pull --ff-only
            Write-Host "[+] Updated Tools -> $toolsDest" -ForegroundColor Green
        }
    } else {
        if ($PSCmdlet.ShouldProcess($toolsDest, "git clone $RepoUrl")) {
            Write-Host "[*] Cloning $RepoUrl -> $toolsDest..." -ForegroundColor Cyan
            & git clone $RepoUrl $toolsDest
            Write-Host "[+] Cloned Tools -> $toolsDest" -ForegroundColor Green
        }
    }
} else {
    Write-Host '[*] git not found; falling back to GitHub ZIP download...' -ForegroundColor Yellow
    $repoBase = $RepoUrl -replace '\.git$', ''
    $zipPath  = Join-Path $zipsDir 'Tools.zip'
    $downloaded = $false

    foreach ($branch in @('main', 'master')) {
        $zipUri = "$repoBase/archive/refs/heads/$branch.zip"
        if ($PSCmdlet.ShouldProcess($zipPath, "Download $zipUri")) {
            try {
                Write-Host "[*] Downloading $zipUri..." -ForegroundColor Cyan
                Invoke-WebRequest -Uri $zipUri -OutFile $zipPath -UseBasicParsing -TimeoutSec 60
                $downloaded = $true
                break
            } catch {
                Write-Warning "Branch '$branch' download failed: $($_.Exception.Message)"
            }
        }
    }

    if ($downloaded -and (Test-Path $zipPath)) {
        if ($PSCmdlet.ShouldProcess($toolsDest, "Extract $zipPath")) {
            $tmpExtract = Join-Path $zipsDir 'Tools_extract_tmp'
            if (Test-Path $tmpExtract) { Remove-Item -Path $tmpExtract -Recurse -Force }
            Expand-Archive -Path $zipPath -DestinationPath $tmpExtract -Force
            $inner = Get-ChildItem -Path $tmpExtract -Directory | Select-Object -First 1
            if ($inner) {
                if (Test-Path $toolsDest) { Remove-Item -Path $toolsDest -Recurse -Force }
                Move-Item -Path $inner.FullName -Destination $toolsDest -Force
            }
            Remove-Item -Path $tmpExtract -Recurse -Force -ErrorAction SilentlyContinue
            Write-Host "[+] Extracted Tools -> $toolsDest" -ForegroundColor Green
        }
    } elseif (-not $WhatIfPreference) {
        Write-Warning "Could not download Tools repository from $RepoUrl."
    }
}

Write-Host "`n[+] Tool staging complete in $BaseDir" -ForegroundColor Green
