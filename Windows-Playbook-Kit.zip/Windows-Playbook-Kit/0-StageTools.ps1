<#
.SYNOPSIS
    Stages CCDC Blue Team directories and downloads tools from https://github.com/Vassilsk1/Tools.git.

.DESCRIPTION
    Creates C:\tools\{logs,scripts,bins,zips}, adds a Windows Defender exclusion for C:\tools,
    and pulls https://github.com/Vassilsk1/Tools.git into C:\tools\bins\Tools.
    Uses shallow git clone (--depth 1) if git is installed, and automatically falls back
    to downloading the GitHub repository ZIP archive if git is missing or fails.

.EXAMPLE
    .\0-StageTools.ps1
    .\0-StageTools.ps1 -CreateDirsOnly
    .\0-StageTools.ps1 -ForceRedownload
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$BaseDir = 'C:\tools',
    [string]$RepoUrl = 'https://github.com/Vassilsk1/Tools.git',
    [switch]$CreateDirsOnly,
    [switch]$ForceRedownload
)

$ErrorActionPreference = 'Stop'

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run 0-StageTools.ps1 from an elevated (Administrator) PowerShell session.'
}

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$dirs = @(
    $BaseDir,
    (Join-Path $BaseDir 'logs'),
    (Join-Path $BaseDir 'scripts'),
    (Join-Path $BaseDir 'bins'),
    (Join-Path $BaseDir 'zips')
)

foreach ($dir in $dirs) {
    if (-not (Test-Path $dir)) {
        if ($PSCmdlet.ShouldProcess($dir, 'Create directory')) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
            Write-Host "[+] Created $dir" -ForegroundColor Green
        }
    }
}

try {
    $mp = Get-MpPreference -ErrorAction SilentlyContinue
    if ($mp -and ($mp.ExclusionPath -notcontains $BaseDir)) {
        if ($PSCmdlet.ShouldProcess($BaseDir, 'Add Defender exclusion for C:\tools')) {
            Add-MpPreference -ExclusionPath $BaseDir -ErrorAction SilentlyContinue
            Write-Host "[+] Added Defender exclusion for $BaseDir" -ForegroundColor Cyan
        }
    }
} catch {
    Write-Warning "Could not configure Defender exclusion for ${BaseDir}: $($_.Exception.Message)"
}

if ($CreateDirsOnly) {
    Write-Host '[*] Directory staging complete (-CreateDirsOnly).' -ForegroundColor Cyan
    return
}

$toolsDest = Join-Path (Join-Path $BaseDir 'bins') 'Tools'
$zipsDir   = Join-Path $BaseDir 'zips'

if ((Test-Path $toolsDest) -and $ForceRedownload) {
    if ($PSCmdlet.ShouldProcess($toolsDest, 'Remove existing Tools folder for fresh download')) {
        Remove-Item -Path $toolsDest -Recurse -Force
    }
}

$clonedOk = $false
$gitCmd = Get-Command git -ErrorAction SilentlyContinue
if ($gitCmd) {
    if (Test-Path (Join-Path $toolsDest '.git')) {
        if ($PSCmdlet.ShouldProcess($toolsDest, "git pull $RepoUrl")) {
            Write-Host "[*] Updating existing Tools repo in $toolsDest..." -ForegroundColor Cyan
            & git -C $toolsDest pull --ff-only
            if ($LASTEXITCODE -eq 0) {
                $clonedOk = $true
                Write-Host "[+] Updated Tools -> $toolsDest" -ForegroundColor Green
            } else {
                Write-Warning 'git pull failed; falling back to ZIP download.'
            }
        }
    } else {
        if ($PSCmdlet.ShouldProcess($toolsDest, "git clone --depth 1 $RepoUrl")) {
            Write-Host "[*] Cloning $RepoUrl -> $toolsDest..." -ForegroundColor Cyan
            & git -c http.postBuffer=524288000 clone --depth 1 $RepoUrl $toolsDest
            if ($LASTEXITCODE -eq 0) {
                $clonedOk = $true
                Write-Host "[+] Cloned Tools -> $toolsDest" -ForegroundColor Green
            } else {
                Write-Warning 'git clone failed (connection reset or timeout); falling back to ZIP download...'
                if (Test-Path $toolsDest) { Remove-Item -Path $toolsDest -Recurse -Force -ErrorAction SilentlyContinue }
            }
        }
    }
}

if (-not $clonedOk -and -not $WhatIfPreference) {
    $repoBase = $RepoUrl -replace '\.git$', ''
    $zipPath  = Join-Path $zipsDir 'Tools.zip'
    $downloaded = $false

    foreach ($branch in @('main', 'master')) {
        $zipUri = "$repoBase/archive/refs/heads/$branch.zip"
        if ($PSCmdlet.ShouldProcess($zipPath, "Download $zipUri")) {
            try {
                Write-Host "[*] Downloading $zipUri..." -ForegroundColor Cyan
                Invoke-WebRequest -Uri $zipUri -OutFile $zipPath -UseBasicParsing -TimeoutSec 120
                $downloaded = $true
                break
            } catch {
                Write-Warning "Branch '$branch' download failed: $($_.Exception.Message)"
            }
        }
    }

    if ($downloaded -and (Test-Path $zipPath)) {
        if ($PSCmdlet.ShouldProcess($toolsDest, "Extract $zipPath")) {
            $tmpExtract = Join-Path $zipsDir 'Tools_extract_tmp'
            if (Test-Path $tmpExtract) { Remove-Item -Path $tmpExtract -Recurse -Force }
            Expand-Archive -Path $zipPath -DestinationPath $tmpExtract -Force
            $inner = Get-ChildItem -Path $tmpExtract -Directory | Select-Object -First 1
            if ($inner) {
                if (Test-Path $toolsDest) { Remove-Item -Path $toolsDest -Recurse -Force }
                Move-Item -Path $inner.FullName -Destination $toolsDest -Force
            }
            Remove-Item -Path $tmpExtract -Recurse -Force -ErrorAction SilentlyContinue
            Write-Host "[+] Extracted Tools -> $toolsDest" -ForegroundColor Green
        }
    } else {
        Write-Warning "Could not download Tools repository from $RepoUrl."
    }
}

Write-Host "`n[+] Tool staging complete in $BaseDir" -ForegroundColor Green
