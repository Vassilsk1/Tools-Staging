<#
.SYNOPSIS
    Bulk or single-account Active Directory password reset with separate Domain Admin password and Black Team exclusions.

.DESCRIPTION
    Combines the fast bulk workflow of ptb/Reset-DomainPasswords.ps1 with safe exclusions
    (bta, bta_admin, seccdc, krbtgt) and clears PasswordNeverExpires (closing AD findings #3 and #20).

.EXAMPLE
    .\4-ResetDomainPasswords.ps1
    .\4-ResetDomainPasswords.ps1 -Exclude bta,bta_admin,seccdc,krbtgt,svc_score
    .\4-ResetDomainPasswords.ps1 -Name jdoe
    .\4-ResetDomainPasswords.ps1 -WhatIf
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [Alias('e')]
    [string[]]$Exclude = @('bta', 'bta_admin', 'seccdc', 'krbtgt'),

    [string]$ExemptFile,

    [string]$Name,

    [SecureString]$UserPassword,

    [SecureString]$AdminPassword,

    [switch]$SkipDomainAdmins,

    [switch]$KeepNonExpiring,

    [string]$LogDir = 'C:\tools\logs'
)

$ErrorActionPreference = 'Stop'

Import-Module ActiveDirectory -ErrorAction Stop

if (-not (Test-Path $LogDir)) {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
}
$logPath = Join-Path $LogDir "DomainPasswordReset_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"

$excludeSet = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
foreach ($item in $Exclude) {
    foreach ($part in ($item -split ',')) {
        $trimmed = $part.Trim()
        if ($trimmed) { [void]$excludeSet.Add($trimmed) }
    }
}
# Always protect krbtgt unless explicitly targeting it by -Name
if (-not $Name) { [void]$excludeSet.Add('krbtgt') }

if ($ExemptFile -and (Test-Path $ExemptFile)) {
    foreach ($line in (Get-Content -Path $ExemptFile)) {
        $trimmed = ($line -replace '#.*$', '').Trim()
        if (-not $trimmed) { continue }
        # Support tab-delimited or whitespace-delimited "Username Password" pastes
        $firstCol = if ($trimmed -match '\t') { ($trimmed -split '\t', 2)[0].Trim() } else { ($trimmed -split '\s+', 2)[0].Trim() }
        if ($firstCol -match '^[-=]+$' -or $firstCol -match '^(?i)(username|user|account|name)$') { continue }
        if ($firstCol -match '\\([^\\]+)$') { $firstCol = $matches[1] }
        if ($firstCol) { [void]$excludeSet.Add($firstCol) }
    }
}

$daMembers = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
try {
    Get-ADGroupMember -Identity 'Domain Admins' -Recursive -ErrorAction Stop |
        Where-Object { $_.objectClass -eq 'user' } |
        ForEach-Object { [void]$daMembers.Add($_.SamAccountName) }
} catch {
    Write-Warning "Could not enumerate Domain Admins: $($_.Exception.Message)"
}

if ($Name) {
    $targets = @(Get-ADUser -Identity $Name -Properties PasswordNeverExpires -ErrorAction Stop)
} else {
    $targets = Get-ADUser -Filter 'Enabled -eq $true' -Properties PasswordNeverExpires |
        Where-Object { -not $excludeSet.Contains($_.SamAccountName) }
}

if (-not $targets -or $targets.Count -eq 0) {
    Write-Host '[*] No matching AD accounts to reset.' -ForegroundColor Yellow
    return
}

$adminTargets = @($targets | Where-Object { $daMembers.Contains($_.SamAccountName) })
$stdTargets   = @($targets | Where-Object { -not $daMembers.Contains($_.SamAccountName) })

Write-Host "[*] Standard AD targets ($($stdTargets.Count)): $($stdTargets.SamAccountName -join ', ')" -ForegroundColor Cyan
if (-not $SkipDomainAdmins) {
    Write-Host "[*] Domain Admin targets ($($adminTargets.Count)): $($adminTargets.SamAccountName -join ', ')" -ForegroundColor Magenta
}

function Read-ConfirmedPassword {
    param([string]$Prompt)
    $p1 = Read-Host -Prompt $Prompt -AsSecureString
    $p2 = Read-Host -Prompt "Confirm $Prompt" -AsSecureString
    $s1 = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($p1))
    $s2 = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($p2))
    if ($s1 -ne $s2) { throw 'Passwords do not match. Aborting.' }
    if ([string]::IsNullOrWhiteSpace($s1)) { throw 'Password cannot be empty.' }
    return $p1
}

if ($stdTargets.Count -gt 0 -and -not $UserPassword -and -not $WhatIfPreference) {
    $UserPassword = Read-ConfirmedPassword -Prompt 'new password for STANDARD AD users'
}

if (-not $SkipDomainAdmins -and $adminTargets.Count -gt 0 -and -not $AdminPassword -and -not $WhatIfPreference) {
    $AdminPassword = Read-ConfirmedPassword -Prompt 'new password for DOMAIN ADMINS'
}

foreach ($user in $stdTargets) {
    if ($PSCmdlet.ShouldProcess($user.SamAccountName, 'Reset AD user password')) {
        try {
            Set-ADAccountPassword -Identity $user.SamAccountName -Reset -NewPassword $UserPassword -ErrorAction Stop
            if (-not $KeepNonExpiring -and $user.PasswordNeverExpires) {
                Set-ADUser -Identity $user.SamAccountName -PasswordNeverExpires $false -ErrorAction SilentlyContinue
            }
            Add-Content -Path $logPath -Value "$(Get-Date -Format 's') [OK][USER] $($user.SamAccountName)"
            Write-Host "[+] Reset user: $($user.SamAccountName)" -ForegroundColor Green
        } catch {
            Add-Content -Path $logPath -Value "$(Get-Date -Format 's') [ERR][USER] $($user.SamAccountName): $($_.Exception.Message)"
            Write-Warning "Failed $($user.SamAccountName): $($_.Exception.Message)"
        }
    }
}

if (-not $SkipDomainAdmins) {
    foreach ($admin in $adminTargets) {
        if ($PSCmdlet.ShouldProcess($admin.SamAccountName, 'Reset Domain Admin password')) {
            try {
                Set-ADAccountPassword -Identity $admin.SamAccountName -Reset -NewPassword $AdminPassword -ErrorAction Stop
                if (-not $KeepNonExpiring -and $admin.PasswordNeverExpires) {
                    Set-ADUser -Identity $admin.SamAccountName -PasswordNeverExpires $false -ErrorAction SilentlyContinue
                }
                Add-Content -Path $logPath -Value "$(Get-Date -Format 's') [OK][DA] $($admin.SamAccountName)"
                Write-Host "[+] Reset Domain Admin: $($admin.SamAccountName)" -ForegroundColor Green
            } catch {
                Add-Content -Path $logPath -Value "$(Get-Date -Format 's') [ERR][DA] $($admin.SamAccountName): $($_.Exception.Message)"
                Write-Warning "Failed $($admin.SamAccountName): $($_.Exception.Message)"
            }
        }
    }
}

Write-Host "[+] Log saved to $logPath" -ForegroundColor Cyan
