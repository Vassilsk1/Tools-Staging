<#
.SYNOPSIS
    Downloads Sysinternals Suite and System Informer into C:\tools\bins.

.DESCRIPTION
    Standalone tool downloader for Sysinternals Suite (extracted to C:\tools\bins\SysinternalsSuite)
    and System Informer (downloaded to C:\tools\bins\systeminformer-setup.exe).

.EXAMPLE
    .\ToolsDownload.ps1
    .\ToolsDownload.ps1 -ForceRedownload
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$BaseDir = 'C:\tools',
    [switch]$ForceRedownload
)

$ErrorActionPreference = 'Stop'

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run ToolsDownload.ps1 from an elevated (Administrator) PowerShell session.'
}

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$zipsDir = Join-Path $BaseDir 'zips'
$binsDir = Join-Path $BaseDir 'bins'
foreach ($d in @($BaseDir, $zipsDir, $binsDir)) {
    if (-not (Test-Path $d)) {
        if ($PSCmdlet.ShouldProcess($d, 'Create directory')) {
            New-Item -ItemType Directory -Path $d -Force | Out-Null
        }
    }
}

# 1. Sysinternals Suite
$sysZip = Join-Path $zipsDir 'SysinternalsSuite.zip'
$sysOut = Join-Path $binsDir 'SysinternalsSuite'
if ((Test-Path $sysOut) -and -not $ForceRedownload) {
    Write-Host "[=] Sysinternals Suite already exists at $sysOut" -ForegroundColor DarkGray
} else {
    if ($PSCmdlet.ShouldProcess($sysOut, 'Download & extract Sysinternals Suite')) {
        Write-Host '[*] Downloading Sysinternals Suite...' -ForegroundColor Cyan
        Invoke-WebRequest -Uri 'https://download.sysinternals.com/files/SysinternalsSuite.zip' -OutFile $sysZip -UseBasicParsing -TimeoutSec 120
        Expand-Archive -Path $sysZip -DestinationPath $sysOut -Force
        Write-Host "[+] Extracted Sysinternals Suite -> $sysOut" -ForegroundColor Green
    }
}

# 2. System Informer
$siExe = Join-Path $binsDir 'systeminformer-setup.exe'
if ((Test-Path $siExe) -and -not $ForceRedownload) {
    Write-Host "[=] System Informer already exists at $siExe" -ForegroundColor DarkGray
} else {
    if ($PSCmdlet.ShouldProcess($siExe, 'Download System Informer')) {
        Write-Host '[*] Downloading System Informer...' -ForegroundColor Cyan
        Invoke-WebRequest -Uri 'https://sourceforge.net/projects/systeminformer/files/systeminformer-3.2.25011-release-setup.exe/download' -OutFile $siExe -UseBasicParsing -TimeoutSec 120
        Write-Host "[+] Downloaded System Informer -> $siExe" -ForegroundColor Green
    }
}

Write-Host "`n[+] ToolsDownload complete in $binsDir" -ForegroundColor Green
