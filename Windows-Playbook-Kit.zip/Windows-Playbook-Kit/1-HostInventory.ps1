<#
.SYNOPSIS
    Captures pre-hardening CCDC host inventory (OS, IPs, domain role, running services, local admins, listening ports).

.DESCRIPTION
    Replaces ptb/inject-the-bear.ps1 with structured console output and automatic log saving to C:\tools\logs\.

.EXAMPLE
    .\1-HostInventory.ps1
    .\1-HostInventory.ps1 -OutDir C:\tools\logs
#>
[CmdletBinding()]
param(
    [string]$OutDir = 'C:\tools\logs'
)

$ErrorActionPreference = 'SilentlyContinue'

if (-not (Test-Path $OutDir)) {
    New-Item -ItemType Directory -Path $OutDir -Force | Out-Null
}

$timestamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$logPath = Join-Path $OutDir "HostInventory_${env:COMPUTERNAME}_${timestamp}.txt"

$cs = Get-CimInstance Win32_ComputerSystem
$os = Get-CimInstance Win32_OperatingSystem

$domainRoleMap = @{
    0 = 'Standalone Workstation'
    1 = 'Member Workstation'
    2 = 'Standalone Server'
    3 = 'Member Server'
    4 = 'Backup Domain Controller'
    5 = 'Primary Domain Controller'
}
$roleCode = [int]$cs.DomainRole
$roleText = if ($domainRoleMap.ContainsKey($roleCode)) { $domainRoleMap[$roleCode] } else { "Unknown ($roleCode)" }
$isDC = $roleCode -in 4, 5

$ips = (Get-NetIPConfiguration | Where-Object { $_.IPv4Address -and $_.NetAdapter.Status -eq 'Up' } | ForEach-Object { $_.IPv4Address.IPAddress } | Sort-Object -Unique) -join ', '
$macs = (Get-NetAdapter | Where-Object { $_.Status -eq 'Up' -and $_.MacAddress } | Select-Object -ExpandProperty MacAddress -Unique) -join ', '

$lines = [System.Collections.Generic.List[string]]::new()
$lines.Add('=== BASIC HOST INFORMATION ===')
$lines.Add("Hostname          : $($env:COMPUTERNAME)")
$lines.Add("IP Address(es)    : $(if ($ips) { $ips } else { 'Not found' })")
$lines.Add("MAC Address(es)   : $(if ($macs) { $macs } else { 'Not found' })")
$lines.Add("Domain Joined     : $([bool]$cs.PartOfDomain)")
$lines.Add("Domain            : $(if ($cs.PartOfDomain) { $cs.Domain } else { 'N/A' })")
$lines.Add("Domain Controller : $isDC ($roleText)")
$lines.Add("OS                : $($os.Caption) ($($os.Version))")
$lines.Add("Last Boot         : $($os.LastBootUpTime)")

$lines.Add('')
$lines.Add('=== LOCAL ADMINISTRATORS ===')
$admins = Get-LocalGroupMember -Group 'Administrators' | Select-Object Name, ObjectClass, PrincipalSource
if ($admins) {
    $lines.Add(($admins | Format-Table -AutoSize | Out-String).TrimEnd())
} else {
    $lines.Add('(Unable to enumerate local Administrators)')
}

$lines.Add('')
$lines.Add('=== LISTENING TCP PORTS ===')
$ports = Get-NetTCPConnection -State Listen | Select-Object LocalAddress, LocalPort, OwningProcess, @{
    Name       = 'Process'
    Expression = { (Get-Process -Id $_.OwningProcess).ProcessName }
} | Sort-Object LocalPort -Unique
if ($ports) {
    $lines.Add(($ports | Format-Table -AutoSize | Out-String).TrimEnd())
}

$lines.Add('')
$lines.Add('=== RUNNING SERVICES ===')
$runningServices = Get-CimInstance Win32_Service | Where-Object { $_.State -eq 'Running' }
$svcList = foreach ($svc in $runningServices) {
    $cleanPath = $null
    if ($svc.PathName -match '^"([^"]+)"') { $cleanPath = $matches[1] }
    elseif ($svc.PathName) { $cleanPath = ($svc.PathName -split '\s+')[0] }
    $ver = 'Unknown'
    if ($cleanPath -and (Test-Path $cleanPath)) {
        $v = (Get-Item $cleanPath).VersionInfo.FileVersion
        if ($v) { $ver = $v }
    }
    [PSCustomObject]@{
        Name        = $svc.Name
        DisplayName = $svc.DisplayName
        StartMode   = $svc.StartMode
        Version     = $ver
        Path        = $cleanPath
    }
}
$lines.Add(($svcList | Sort-Object Name | Format-Table -AutoSize Name, DisplayName, StartMode, Version | Out-String).TrimEnd())

$report = $lines -join [Environment]::NewLine
$report | Set-Content -Path $logPath -Encoding UTF8
Write-Host $report
Write-Host "`n[+] Inventory saved to: $logPath" -ForegroundColor Green
