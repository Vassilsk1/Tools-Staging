<#
.SYNOPSIS
    Bulk or single-account local user password reset with Black Team exclusions.

.DESCRIPTION
    Combines the fast bulk workflow of ptb/yousir.ps1 with the safety and logging
    of Windows-Playbook-Kit. By default resets all enabled local accounts except
    built-in system accounts and Black Team accounts (bta, bta_admin, seccdc).
    Also clears PasswordNeverExpires on reset accounts unless -KeepNonExpiring is set.

.EXAMPLE
    .\3-ResetLocalPasswords.ps1
    .\3-ResetLocalPasswords.ps1 -Exclude bta,bta_admin,seccdc,scoring
    .\3-ResetLocalPasswords.ps1 -Name Administrator
    .\3-ResetLocalPasswords.ps1 -WhatIf
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [Alias('e')]
    [string[]]$Exclude = @('bta', 'bta_admin', 'seccdc', 'Guest', 'DefaultAccount', 'WDAGUtilityAccount'),

    [string]$ExemptFile,

    [string]$Name,

    [SecureString]$Password,

    [switch]$KeepNonExpiring,

    [string]$LogDir = 'C:\tools\logs'
)

$ErrorActionPreference = 'Stop'

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run 3-ResetLocalPasswords.ps1 as Administrator.'
}

$role = (Get-CimInstance Win32_ComputerSystem).DomainRole
if ($role -in 4, 5) {
    throw 'This host is a Domain Controller! Do NOT run 3-ResetLocalPasswords.ps1 on a DC (it can reset machine accounts ending in $ and break domain trust). Use 4-ResetDomainPasswords.ps1 instead.'
}

if (-not (Test-Path $LogDir)) {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
}
$logPath = Join-Path $LogDir "LocalPasswordReset_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"

# Build exclusion set (case-insensitive)
$excludeSet = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
foreach ($item in $Exclude) {
    foreach ($part in ($item -split ',')) {
        $trimmed = $part.Trim()
        if ($trimmed) { [void]$excludeSet.Add($trimmed) }
    }
}

if ($ExemptFile -and (Test-Path $ExemptFile)) {
    foreach ($line in (Get-Content -Path $ExemptFile)) {
        $trimmed = ($line -replace '#.*$', '').Trim()
        if (-not $trimmed) { continue }
        # Support tab-delimited or whitespace-delimited "Username Password" pastes
        $firstCol = if ($trimmed -match '\t') { ($trimmed -split '\t', 2)[0].Trim() } else { ($trimmed -split '\s+', 2)[0].Trim() }
        if ($firstCol -match '^[-=]+$' -or $firstCol -match '^(?i)(username|user|account|name)$') { continue }
        if ($firstCol -match '\\([^\\]+)$') { $firstCol = $matches[1] }
        if ($firstCol) { [void]$excludeSet.Add($firstCol) }
    }
}

# Resolve target accounts
if ($Name) {
    $user = Get-LocalUser -Name $Name -ErrorAction Stop
    $targets = @($user)
} else {
    $targets = Get-LocalUser | Where-Object {
        $_.Enabled -and ($_.Name -notlike '*$') -and (-not $excludeSet.Contains($_.Name))
    }
}

if (-not $targets -or $targets.Count -eq 0) {
    Write-Host '[*] No matching local accounts to reset.' -ForegroundColor Yellow
    return
}

Write-Host "[*] Target local accounts ($($targets.Count)): $($targets.Name -join ', ')" -ForegroundColor Cyan

if (-not $Password -and -not $WhatIfPreference) {
    $Password = Read-Host -Prompt 'Enter new password for target local accounts' -AsSecureString
    $confirm  = Read-Host -Prompt 'Confirm new password' -AsSecureString
    $b1 = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($Password))
    $b2 = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($confirm))
    if ($b1 -ne $b2) {
        throw 'Passwords do not match. Aborting without changes.'
    }
    if ([string]::IsNullOrWhiteSpace($b1)) {
        throw 'Password cannot be empty.'
    }
}

foreach ($user in $targets) {
    $actionDesc = if ($KeepNonExpiring) { 'Reset local password' } else { 'Reset local password & clear PasswordNeverExpires' }
    if ($PSCmdlet.ShouldProcess($user.Name, $actionDesc)) {
        try {
            Set-LocalUser -Name $user.Name -Password $Password -ErrorAction Stop
            if (-not $KeepNonExpiring) {
                Set-LocalUser -Name $user.Name -PasswordNeverExpires $false -ErrorAction SilentlyContinue
            }
            $msg = "$(Get-Date -Format 's') [OK] Reset local account: $($user.Name)"
            Add-Content -Path $logPath -Value $msg
            Write-Host "[+] Reset $($user.Name)" -ForegroundColor Green
        } catch {
            $msg = "$(Get-Date -Format 's') [ERR] $($user.Name): $($_.Exception.Message)"
            Add-Content -Path $logPath -Value $msg
            Write-Warning "Failed to reset $($user.Name): $($_.Exception.Message)"
        }
    }
}

Write-Host "[+] Log saved to $logPath" -ForegroundColor Cyan
