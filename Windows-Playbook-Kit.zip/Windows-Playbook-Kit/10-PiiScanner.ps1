<#
.SYNOPSIS
    Scans local directories for potential PII (SSN, Credit Card, Phone, Address, Email).

.DESCRIPTION
    Replaces ptb/peyeeye.ps1 with configurable -Paths, clean exclusions (AppData, C:\tools),
    and timestamped report output in C:\tools\logs\.

.EXAMPLE
    .\10-PiiScanner.ps1
    .\10-PiiScanner.ps1 -Paths C:\Users,C:\inetpub
#>
[CmdletBinding()]
param(
    [string[]]$Paths = @('C:\Users'),
    [string]$LogDir = 'C:\tools\logs'
)

$ErrorActionPreference = 'SilentlyContinue'
$sw = [System.Diagnostics.Stopwatch]::StartNew()

if (-not (Test-Path $LogDir)) {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
}
$logFile = Join-Path $LogDir "PII_Scan_Report_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"

$piiPatterns = @(
    @{ Label = 'SSN';         Pattern = '\b\d{3}[-.\s]?\d{2}[-.\s]?\d{4}\b' },
    @{ Label = 'CreditCard';  Pattern = '\b\d{13,16}\b' },
    @{ Label = 'Phone';       Pattern = '\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b' },
    @{ Label = 'Address';     Pattern = '\b\d{1,5}\s\w+(\s\w+)*\s(Street|St|Avenue|Ave|Road|Rd|Boulevard|Blvd|Drive|Dr|Court|Ct|Lane|Ln|Way|Highway|Hwy)\b' },
    @{ Label = 'Email';       Pattern = '\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b' }
)

$found = @{}
foreach ($p in $Paths) {
    if (-not (Test-Path $p)) { continue }
    Write-Host "[*] Scanning $p for PII..." -ForegroundColor Cyan
    Get-ChildItem -Path $p -Recurse -File -Force -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -ne 'desktop.ini' -and $_.FullName -notmatch 'AppData|CH-DC|C:\\tools' -and $_.Length -lt 10MB } |
        ForEach-Object {
            $content = Get-Content -Path $_.FullName -Raw -ErrorAction SilentlyContinue
            if (-not $content) { return }
            foreach ($pat in $piiPatterns) {
                $matches = [regex]::Matches($content, $pat.Pattern)
                if ($matches.Count -gt 0) {
                    if (-not $found.ContainsKey($_.FullName)) { $found[$_.FullName] = [System.Collections.Generic.List[string]]::new() }
                    foreach ($m in ($matches | Select-Object -ExpandProperty Value -Unique)) {
                        $found[$_.FullName].Add("$($pat.Label): $m")
                    }
                }
            }
        }
}

$sw.Stop()
if ($found.Count -gt 0) {
    Write-Host "[!] Potential PII found in $($found.Count) file(s):" -ForegroundColor Yellow
    foreach ($kv in $found.GetEnumerator()) {
        Add-Content -Path $logFile -Value "`nFile: $($kv.Key)"
        Write-Host "  $($kv.Key)" -ForegroundColor Yellow
        foreach ($item in $kv.Value) {
            Add-Content -Path $logFile -Value "    - $item"
            Write-Host "    - $item" -ForegroundColor Red
        }
    }
    Write-Host "[+] Report saved to $logFile (elapsed: $([math]::Round($sw.Elapsed.TotalSeconds, 2))s)" -ForegroundColor Cyan
} else {
    Write-Host "[+] No PII detected (elapsed: $([math]::Round($sw.Elapsed.TotalSeconds, 2))s)." -ForegroundColor Green
}
