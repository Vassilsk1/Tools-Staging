<#
.SYNOPSIS
    Continuously monitors Windows Defender state and exclusions, reverting unauthorized changes.

.DESCRIPTION
    Runs in foreground or as a background PowerShell job (-Background). Every -IntervalSeconds:
      1. Ensures WinDefend service is running and Real-Time/Behavior/IOAV/Script/IPS are enabled.
      2. Removes any DisableAntiSpyware / DisableRealtimeMonitoring policy overrides.
      3. Clears any Policy-level Defender exclusions (HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions).
      4. Audits MpPreference exclusions against the allowed list (C:\tools + BTA + custom -AllowedPaths)
         and immediately removes any unauthorized path, extension, process, or IP exclusion.

.EXAMPLE
    .\13-DefenderWatchdog.ps1
    .\13-DefenderWatchdog.ps1 -Background
    .\13-DefenderWatchdog.ps1 -AllowedPaths 'C:\tools','C:\Program Files\BTA' -IntervalSeconds 10
#>
[CmdletBinding()]
param(
    [string[]]$AllowedPaths = @('C:\tools'),
    [string[]]$AllowedExtensions = @(),
    [string[]]$AllowedProcesses = @(),
    [string[]]$AllowedIPs = @(),
    [int]$IntervalSeconds = 15,
    [switch]$Background,
    [string]$LogDir = 'C:\tools\logs'
)

$ErrorActionPreference = 'SilentlyContinue'

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run 13-DefenderWatchdog.ps1 from an elevated (Administrator) PowerShell session.'
}

if (-not (Test-Path $LogDir)) {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
}
$logPath = Join-Path $LogDir 'DefenderWatchdog.log'

if (Test-Path 'C:\Program Files\BTA') {
    if ($AllowedPaths -notcontains 'C:\Program Files\BTA') {
        $AllowedPaths += 'C:\Program Files\BTA'
    }
}

Write-Host "[*] DefenderWatchdog monitoring every ${IntervalSeconds}s (Allowed paths: $($AllowedPaths -join ', '))" -ForegroundColor Cyan

$watchBlock = {
    param($AllowPaths, $AllowExts, $AllowProcs, $AllowIPs, $Interval, $LogFile)

    function Log-Alert {
        param([string]$Msg, [string]$Color = 'Yellow')
        $line = "$(Get-Date -Format 's') $Msg"
        Add-Content -Path $LogFile -Value $line
        Write-Host $line -ForegroundColor $Color
    }

    while ($true) {
        # 1. Ensure WinDefend service is running
        $svc = Get-Service -Name 'WinDefend' -ErrorAction SilentlyContinue
        if ($svc -and $svc.Status -ne 'Running') {
            Log-Alert '[ALERT] WinDefend was stopped — starting service...' 'Red'
            Start-Service -Name 'WinDefend' -ErrorAction SilentlyContinue
        }

        # 2. Clear Defender disable policy keys
        $defPol = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender'
        foreach ($v in @('DisableAntiSpyware', 'DisableAntiVirus')) {
            if ((Get-ItemProperty -Path $defPol -Name $v -ErrorAction SilentlyContinue).$v -eq 1) {
                Set-ItemProperty -Path $defPol -Name $v -Value 0 -Force -ErrorAction SilentlyContinue
                Log-Alert "[ALERT] Reverted policy $v = 0" 'Red'
            }
        }
        $rtpPol = "$defPol\Real-Time Protection"
        foreach ($v in @('DisableRealtimeMonitoring', 'DisableBehaviorMonitoring', 'DisableIOAVProtection')) {
            if ((Get-ItemProperty -Path $rtpPol -Name $v -ErrorAction SilentlyContinue).$v -eq 1) {
                Set-ItemProperty -Path $rtpPol -Name $v -Value 0 -Force -ErrorAction SilentlyContinue
                Log-Alert "[ALERT] Reverted RTP policy $v = 0" 'Red'
            }
        }

        # 3. Clear policy-level exclusions
        foreach ($sub in @('Paths', 'Extensions', 'Processes', 'IpAddresses')) {
            $polExcl = "$defPol\Exclusions\$sub"
            if (Test-Path $polExcl) {
                Remove-Item -Path $polExcl -Recurse -Force -ErrorAction SilentlyContinue
                Log-Alert "[ALERT] Cleared policy Defender exclusions: $sub" 'Red'
            }
        }

        # 4. Enforce MpPreference Real-Time Monitoring & Audit Exclusions
        $mp = Get-MpPreference -ErrorAction SilentlyContinue
        if ($mp) {
            if ($mp.DisableRealtimeMonitoring -or $mp.DisableBehaviorMonitoring -or $mp.DisableIOAVProtection -or $mp.DisableScriptScanning -or ($mp.EnableControlledFolderAccess -ne 1) -or ($mp.EnableNetworkProtection -ne 1) -or ($mp.PUAProtection -ne 1)) {
                Log-Alert '[ALERT] Defender/CFA/Network/PUA protection was disabled — re-enabling...' 'Red'
                Set-MpPreference -DisableRealtimeMonitoring $false -DisableBehaviorMonitoring $false -DisableIOAVProtection $false -DisableScriptScanning $false -ErrorAction SilentlyContinue
                Set-MpPreference -EnableControlledFolderAccess Enabled -ErrorAction SilentlyContinue
                Set-MpPreference -EnableNetworkProtection Enabled -ErrorAction SilentlyContinue
                Set-MpPreference -PUAProtection Enabled -ErrorAction SilentlyContinue
            }

            foreach ($p in @($mp.ExclusionPath)) {
                if ($p -and ($AllowPaths -notcontains $p)) {
                    Remove-MpPreference -ExclusionPath $p -ErrorAction SilentlyContinue
                    Log-Alert "[ALERT] Removed unauthorized ExclusionPath: $p" 'Red'
                }
            }
            foreach ($e in @($mp.ExclusionExtension)) {
                if ($e -and ($AllowExts -notcontains $e)) {
                    Remove-MpPreference -ExclusionExtension $e -ErrorAction SilentlyContinue
                    Log-Alert "[ALERT] Removed unauthorized ExclusionExtension: $e" 'Red'
                }
            }
            foreach ($pr in @($mp.ExclusionProcess)) {
                if ($pr -and ($AllowProcs -notcontains $pr)) {
                    Remove-MpPreference -ExclusionProcess $pr -ErrorAction SilentlyContinue
                    Log-Alert "[ALERT] Removed unauthorized ExclusionProcess: $pr" 'Red'
                }
            }
            foreach ($ip in @($mp.ExclusionIpAddress)) {
                if ($ip -and ($AllowIPs -notcontains $ip)) {
                    Remove-MpPreference -ExclusionIpAddress $ip -ErrorAction SilentlyContinue
                    Log-Alert "[ALERT] Removed unauthorized ExclusionIpAddress: $ip" 'Red'
                }
            }

            # Ensure allowed paths remain excluded
            foreach ($ap in $AllowPaths) {
                if ($mp.ExclusionPath -notcontains $ap) {
                    Add-MpPreference -ExclusionPath $ap -ErrorAction SilentlyContinue
                }
            }
        }

        Start-Sleep -Seconds $Interval
    }
}

if ($Background) {
    $job = Start-Job -Name 'CCDC-DefenderWatchdog' -ScriptBlock $watchBlock -ArgumentList $AllowedPaths, $AllowedExtensions, $AllowedProcesses, $AllowedIPs, $IntervalSeconds, $logPath
    Write-Host "[+] DefenderWatchdog started in background (Job ID $($job.Id)). Check with: Get-Job | Receive-Job" -ForegroundColor Green
} else {
    Write-Host '[*] Running in foreground (Ctrl+C to stop)...' -ForegroundColor DarkGray
    & $watchBlock $AllowedPaths $AllowedExtensions $AllowedProcesses $AllowedIPs $IntervalSeconds $logPath
}
