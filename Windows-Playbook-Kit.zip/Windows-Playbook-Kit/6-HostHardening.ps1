<#
.SYNOPSIS
    Unified CCDC Windows host hardening script with Safe (default) and Strict profiles.

.DESCRIPTION
    Replaces 1-HostHardening.ps1, ptb/playin.ps1, ptb/stone.ps1, and All/Hard.ps1.
    Runs on both Domain Controllers and Workstations/Member Servers.
    Enables SMB Signing (opt out with -SkipSmbSigning), disables LLMNR/NetBIOS/SMBv1/Spooler,
    hardens Defender + ASR (preserving C:\tools and C:\Program Files\BTA), enables full
    auditpol + 4688 + 64/32-bit PowerShell logging, UAC/LSA/WDigest/RunAsPPL, DEP AlwaysOn,
    and RDP NLA.

.EXAMPLE
    .\6-HostHardening.ps1
    .\6-HostHardening.ps1 -Profile Strict
    .\6-HostHardening.ps1 -SkipSmbSigning -KeepSpooler
    .\6-HostHardening.ps1 -Control Defender
    .\6-HostHardening.ps1 -WhatIf
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [ValidateSet('Safe', 'Strict')]
    [string]$Profile = 'Safe',

    [ValidateSet(
        'All', 'BuiltInAccounts', 'Defender', 'AuditPolicy', 'Logging',
        'UacAndLsa', 'SmbAndNet', 'Services', 'DepAndRdp', 'StickyKeys', 'DisableWinRM'
    )]
    [string]$Control = 'All',

    [switch]$KeepSpooler,
    [switch]$SkipSmbSigning,
    [switch]$RemoveStickyKeys,
    [string]$LogDir = 'C:\tools\logs'
)

$ErrorActionPreference = 'Continue'

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run 6-HostHardening.ps1 from an elevated (Administrator) PowerShell session.'
}

if (-not (Test-Path $LogDir)) {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
}
$logPath = Join-Path $LogDir "HostHardening_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"

function Write-Log {
    param([string]$Message, [ConsoleColor]$Color = 'Gray')
    $entry = "$(Get-Date -Format 's') $Message"
    Add-Content -Path $logPath -Value $entry
    Write-Host $Message -ForegroundColor $Color
}

function Set-RegValue {
    param(
        [string]$Path,
        [string]$Name,
        [object]$Value,
        [ValidateSet('DWord', 'String', 'MultiString')]
        [string]$Type = 'DWord'
    )
    if ($PSCmdlet.ShouldProcess("$Path\$Name", "Set $Type = $Value")) {
        try {
            if (-not (Test-Path $Path)) {
                New-Item -Path $Path -Force -ErrorAction Stop | Out-Null
            }
            New-ItemProperty -Path $Path -Name $Name -Value $Value -PropertyType $Type -Force -ErrorAction Stop | Out-Null
        } catch [System.Security.SecurityException], [System.UnauthorizedAccessException] {
            Write-Log "[=] Skipped Tamper-Protected/locked registry key: $Path\$Name" DarkGray
        } catch {
            Write-Log "[!] Could not set $Path\$Name : $($_.Exception.Message)" Yellow
        }
    }
}

function Invoke-BuiltInAccounts {
    Write-Log '[*] Disabling Guest, DefaultAccount, and WDAGUtilityAccount...' Cyan
    foreach ($acct in @('Guest', 'DefaultAccount', 'WDAGUtilityAccount')) {
        $u = Get-LocalUser -Name $acct -ErrorAction SilentlyContinue
        if ($u -and $u.Enabled) {
            if ($PSCmdlet.ShouldProcess($acct, 'Disable built-in local account')) {
                Disable-LocalUser -Name $acct -ErrorAction SilentlyContinue
                Write-Log "[+] Disabled local account: $acct" Green
            }
        }
    }
}

function Invoke-DefenderHardening {
    Write-Log '[*] Hardening Windows Defender & ASR rules (preserving BTA/tools exclusions)...' Cyan
    $defPolicies = @(
        @('HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender', 'DisableAntiSpyware', 0),
        @('HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender', 'DisableAntiVirus', 0),
        @('HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender', 'ServiceKeepAlive', 1),
        @('HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection', 'DisableRealtimeMonitoring', 0),
        @('HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection', 'DisableBehaviorMonitoring', 0),
        @('HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection', 'DisableIOAVProtection', 0),
        @('HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Scan', 'DisableHeuristics', 0),
        @('HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Scan', 'DisableArchiveScanning', 0),
        @('HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Scan', 'CheckForSignaturesBeforeRunningScan', 1),
        @('HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet', 'SpyNetReporting', 2),
        @('HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet', 'SubmitSamplesConsent', 3),
        @('HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet', 'DisableBlockAtFirstSeen', 0),
        @('HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\MpEngine', 'MpCloudBlockLevel', 6)
    )
    foreach ($p in $defPolicies) { Set-RegValue -Path $p[0] -Name $p[1] -Value $p[2] }
    $mpStatus = Get-MpComputerStatus -ErrorAction SilentlyContinue
    if ($mpStatus -and $mpStatus.IsTamperProtected) {
        Write-Log '[=] Defender Tamper Protection is already active.' DarkGray
    } else {
        Set-RegValue -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Features' -Name 'TamperProtection' -Value 5
    }

    # Reputation-based protection (SmartScreen for Windows + Edge + PUA) & Controlled Folder Access + Network Protection
    $repPolicies = @(
        @('HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender', 'PUAProtection', 1, 'DWord'),
        @('HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Windows Defender Exploit Guard\Controlled Folder Access', 'EnableControlledFolderAccess', 1, 'DWord'),
        @('HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Windows Defender Exploit Guard\Network Protection', 'EnableNetworkProtection', 1, 'DWord'),
        @('HKLM:\SOFTWARE\Policies\Microsoft\Windows\System', 'EnableSmartScreen', 1, 'DWord'),
        @('HKLM:\SOFTWARE\Policies\Microsoft\Windows\System', 'ShellSmartScreenLevel', 'Block', 'String'),
        @('HKLM:\SOFTWARE\Policies\Microsoft\MicrosoftEdge\PhishingFilter', 'EnabledV9', 1, 'DWord'),
        @('HKLM:\SOFTWARE\Policies\Microsoft\Edge', 'SmartScreenEnabled', 1, 'DWord'),
        @('HKLM:\SOFTWARE\Policies\Microsoft\Edge', 'SmartScreenPuaEnabled', 1, 'DWord')
    )
    foreach ($rp in $repPolicies) { Set-RegValue -Path $rp[0] -Name $rp[1] -Value $rp[2] -Type $rp[3] }

    # Core Isolation: Memory Integrity (HVCI) & VBS (applies across Win 10/11/Server 2019-2025; takes effect on reboot)
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard' -Name 'EnableVirtualizationBasedSecurity' -Value 1
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' -Name 'Enabled' -Value 1
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' -Name 'WasEnabledBy' -Value 1
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -Name 'RunAsPPLBoot' -Value 1

    if ($PSCmdlet.ShouldProcess('WinDefend', 'Start service & configure all Defender protections')) {
        Start-Service -Name WinDefend -ErrorAction SilentlyContinue
        # Apply each MpPreference setting safely so older Server 2019 / Win 10 builds never abort on newer flags
        $mpSettings = @{
            DisableRealtimeMonitoring                 = $false
            DisableBehaviorMonitoring                 = $false
            DisableIOAVProtection                     = $false
            DisableScriptScanning                     = $false
            DisableArchiveScanning                    = $false
            DisableIntrusionPreventionSystem          = $false
            DisableEmailScanning                      = $false
            DisableRemovableDriveScanning             = $false
            DisableScanningMappedNetworkDrivesForFullScan = $false
            DisableScanningNetworkFiles               = $false
            CheckForSignaturesBeforeRunningScan       = $true
            PUAProtection                             = 'Enabled'
            EnableControlledFolderAccess              = 'Enabled'
            EnableNetworkProtection                   = 'Enabled'
            MAPSReporting                             = 'Advanced'
            CloudBlockLevel                           = 'High'
        }
        foreach ($kv in $mpSettings.GetEnumerator()) {
            $splat = @{ $kv.Key = $kv.Value; ErrorAction = 'SilentlyContinue' }
            Set-MpPreference @splat
        }

        $keepPaths = @('C:\tools')
        if (Test-Path 'C:\Program Files\BTA') { $keepPaths += 'C:\Program Files\BTA' }

        # Clear Policy-level Defender exclusions (which block GUI and Remove-MpPreference removal)
        foreach ($sub in @('Paths', 'Extensions', 'Processes', 'IpAddresses')) {
            $polExcl = "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\$sub"
            if (Test-Path $polExcl) {
                Remove-Item -Path $polExcl -Recurse -Force -ErrorAction SilentlyContinue
                Write-Log "[+] Cleared policy Defender exclusions: $sub" Green
            }
        }

        # Clear preference-level exclusions individually, then reset cleanly keeping only C:\tools (+ BTA if present)
        $mp = Get-MpPreference -ErrorAction SilentlyContinue
        if ($mp) {
            foreach ($ep in @($mp.ExclusionPath)) {
                if ($ep -and ($keepPaths -notcontains $ep)) {
                    Remove-MpPreference -ExclusionPath $ep -ErrorAction SilentlyContinue
                }
            }
            foreach ($ee in @($mp.ExclusionExtension)) {
                if ($ee) { Remove-MpPreference -ExclusionExtension $ee -ErrorAction SilentlyContinue }
            }
            foreach ($pr in @($mp.ExclusionProcess)) {
                if ($pr) { Remove-MpPreference -ExclusionProcess $pr -ErrorAction SilentlyContinue }
            }
            foreach ($ip in @($mp.ExclusionIpAddress)) {
                if ($ip) { Remove-MpPreference -ExclusionIpAddress $ip -ErrorAction SilentlyContinue }
            }
        }
        foreach ($kp in $keepPaths) {
            Add-MpPreference -ExclusionPath $kp -ErrorAction SilentlyContinue
        }
        Write-Log "[+] Defender exclusions cleaned (preserved: $($keepPaths -join ', '))." Green

        $asrIds = @(
            '75668C1F-73B5-4CF0-BB93-3ECF5CB7CC84',
            '3B576869-A4EC-4529-8536-B80A7769E899',
            'D4F940AB-401B-4EfC-AADC-AD5F3C50688A',
            'D3E037E1-3EB8-44C8-A917-57927947596D',
            '5BEB7EFE-FD9A-4556-801D-275E5FFC04CC',
            'BE9BA2D9-53EA-4CDC-84E5-9B1EEEE46550',
            '92E97FA1-2EDF-4476-BDD6-9DD0B4DDDC7B',
            'D1E49AAC-8F56-4280-B9BA-993A6D77406C',
            'B2B3F03D-6A65-4F7B-A9C7-1C7EF74A9BA4',
            'C1DB55AB-C21A-4637-BB3F-A12568109D35',
            '9E6C4E1F-7D60-472F-BA1A-A39EF669E4B2',
            'E6DB77E5-3DF2-4CF1-B95A-636979351E5B'
        )
        foreach ($id in $asrIds) {
            Add-MpPreference -AttackSurfaceReductionRules_Ids $id -AttackSurfaceReductionRules_Actions Enabled -ErrorAction SilentlyContinue
        }
        Write-Log '[+] Defender & ASR rules configured.' Green
    }
}

function Invoke-AuditPolicy {
    Write-Log '[*] Enabling comprehensive Windows Audit Policy (auditpol)...' Cyan
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -Name 'SCENoApplyLegacyAuditPolicy' -Value 1
    if ($PSCmdlet.ShouldProcess('auditpol', 'Enable success and failure auditing for all categories')) {
        & auditpol.exe /set /category:* /success:enable /failure:enable | Out-Null
        Write-Log '[+] Audit policy enabled for all categories.' Green
    }
}

function Invoke-LoggingHardening {
    Write-Log '[*] Enabling Process Creation (4688 + CLI) and 64-bit/32-bit PowerShell Logging...' Cyan
    Set-RegValue -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit' -Name 'ProcessCreationIncludeCmdLine_Enabled' -Value 1

    Set-RegValue -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging' -Name 'EnableScriptBlockLogging' -Value 1
    Set-RegValue -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging' -Name 'EnableModuleLogging' -Value 1
    Set-RegValue -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging\ModuleNames' -Name '*' -Value '*' -Type String

    Set-RegValue -Path 'HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging' -Name 'EnableScriptBlockLogging' -Value 1
    Set-RegValue -Path 'HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\PowerShell\ModuleLogging' -Name 'EnableModuleLogging' -Value 1
    Set-RegValue -Path 'HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\PowerShell\ModuleLogging\ModuleNames' -Name '*' -Value '*' -Type String
    Write-Log '[+] Logging policies configured.' Green
}

function Invoke-UacAndLsa {
    Write-Log '[*] Hardening UAC, LSA, WDigest, LSASS PPL, and Password Filters...' Cyan
    Set-RegValue -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableLUA' -Value 1
    Set-RegValue -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'ConsentPromptBehaviorAdmin' -Value 1
    Set-RegValue -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'ConsentPromptBehaviorUser' -Value 0
    Set-RegValue -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'PromptOnSecureDesktop' -Value 1
    Set-RegValue -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableInstallerDetection' -Value 1
    Set-RegValue -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'LocalAccountTokenFilterPolicy' -Value 0

    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -Name 'NoLMHash' -Value 1
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -Name 'LimitBlankPasswordUse' -Value 1
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -Name 'RunAsPPL' -Value 1
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -Name 'Notification Packages' -Value @('scecli') -Type MultiString
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest' -Name 'UseLogonCredential' -Value 0
    Set-RegValue -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Installer' -Name 'AlwaysInstallElevated' -Value 0
    Set-RegValue -Path 'HKCU:\SOFTWARE\Policies\Microsoft\Windows\Installer' -Name 'AlwaysInstallElevated' -Value 0

    Set-RegValue -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoAutorun' -Value 1
    Set-RegValue -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoDriveTypeAutoRun' -Value 255
    Set-RegValue -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name 'AutoAdminLogon' -Value 0
    Write-Log '[+] UAC and LSA hardening applied.' Green
}

function Invoke-SmbAndNet {
    Write-Log '[*] Hardening SMB (SMBv1 off, SMBv2 on, SMB Signing), LLMNR off, NetBIOS off, PrintNightmare...' Cyan
    if ($PSCmdlet.ShouldProcess('SMB1Protocol', 'Disable SMBv1 and enable SMBv2')) {
        Set-SmbServerConfiguration -EnableSMB1Protocol $false -EnableSMB2Protocol $true -Force -ErrorAction SilentlyContinue
        Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -NoRestart -ErrorAction SilentlyContinue | Out-Null
    }
    if (-not $SkipSmbSigning) {
        if ($PSCmdlet.ShouldProcess('SMB Signing', 'Require SMB Security Signature (Server & Client)')) {
            Set-SmbServerConfiguration -RequireSecuritySignature $true -Force -ErrorAction SilentlyContinue
            Set-SmbClientConfiguration -RequireSecuritySignature $true -Force -ErrorAction SilentlyContinue
            Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' -Name 'RequireSecuritySignature' -Value 1
            Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters' -Name 'RequireSecuritySignature' -Value 1
            Write-Log '[+] SMB Signing required (Server & Client).' Green
        }
    }

    # Disable LLMNR
    Set-RegValue -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' -Name 'EnableMultiCast' -Value 0

    # Disable NetBIOS over TCP/IP on all interfaces
    $netbtBase = 'HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters\Interfaces'
    if (Test-Path $netbtBase) {
        foreach ($ifKey in (Get-ChildItem $netbtBase)) {
            Set-RegValue -Path $ifKey.PSPath -Name 'NetbiosOptions' -Value 2
        }
    }

    # PrintNightmare mitigations
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Print\Providers\LanMan Print Services\Servers' -Name 'AddPrinterDrivers' -Value 1
    Set-RegValue -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers' -Name 'RegisterSpoolerRemoteRpcEndPoint' -Value 2
    Set-RegValue -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint' -Name 'RestrictDriverInstallationToAdministrators' -Value 1

    if ($Profile -eq 'Strict') {
        Write-Log '[*] [Strict] Disabling IPv6 bindings on active adapters...' Yellow
        if ($PSCmdlet.ShouldProcess('NetAdapter ms_tcpip6', 'Disable IPv6 bindings')) {
            Get-NetAdapter | ForEach-Object { Disable-NetAdapterBinding -InterfaceAlias $_.Name -ComponentID ms_tcpip6 -Confirm:$false -ErrorAction SilentlyContinue }
        }
    }
    # Ensure all three Windows Firewall profiles (Domain, Private, Public) are enabled
    foreach ($fwProf in @('DomainProfile', 'StandardProfile', 'PublicProfile')) {
        $fwPol = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\$fwProf"
        if (Test-Path $fwPol) {
            if ((Get-ItemProperty -Path $fwPol -Name 'EnableFirewall' -ErrorAction SilentlyContinue).EnableFirewall -eq 0) {
                Set-RegValue -Path $fwPol -Name 'EnableFirewall' -Value 1
            }
        }
    }
    if ($PSCmdlet.ShouldProcess('Windows Firewall', 'Enable Domain, Private, and Public profiles (keep RDP/SSH open)')) {
        Start-Service -Name mpssvc -ErrorAction SilentlyContinue
        Set-Service -Name mpssvc -StartupType Automatic -ErrorAction SilentlyContinue
        Set-NetFirewallProfile -Profile Domain,Private,Public -Enabled True -ErrorAction SilentlyContinue
        foreach ($mgmt in @(@('CCDC-Allow-RDP', 3389), @('CCDC-Allow-SSH', 22))) {
            if (-not (Get-NetFirewallRule -DisplayName $mgmt[0] -ErrorAction SilentlyContinue)) {
                New-NetFirewallRule -DisplayName $mgmt[0] -Direction Inbound -Action Allow -Protocol TCP -LocalPort $mgmt[1] -Profile Any -Enabled True -ErrorAction SilentlyContinue | Out-Null
            }
        }
        Write-Log '[+] Windows Firewall enabled across Domain, Private, and Public profiles.' Green
    }

    Write-Log '[+] Network & SMB hardening applied.' Green
}

function Invoke-ServiceHardening {
    Write-Log '[*] Hardening risky services (RemoteRegistry, Spooler)...' Cyan
    $svcNames = @('RemoteRegistry')
    if (-not $KeepSpooler) { $svcNames += 'Spooler' }

    foreach ($s in $svcNames) {
        $svc = Get-Service -Name $s -ErrorAction SilentlyContinue
        if ($svc) {
            if ($PSCmdlet.ShouldProcess($s, 'Stop and disable service')) {
                Stop-Service -Name $s -Force -ErrorAction SilentlyContinue
                Set-Service -Name $s -StartupType Disabled -ErrorAction SilentlyContinue
                Write-Log "[+] Stopped & disabled service: $s" Green
            }
        }
    }

    # If IIS (W3SVC) is installed (e.g. borgar Food Ordering Service), harden directory browsing safely
    if ((Get-Service -Name 'W3SVC' -ErrorAction SilentlyContinue) -and (Get-Module -ListAvailable -Name WebAdministration)) {
        if ($PSCmdlet.ShouldProcess('IIS', 'Disable directory browsing')) {
            Import-Module WebAdministration -ErrorAction SilentlyContinue
            Set-WebConfigurationProperty -Filter '/system.webServer/directoryBrowse' -Name 'enabled' -Value $false -PSPath 'IIS:' -ErrorAction SilentlyContinue
            Write-Log '[+] Hardened IIS (disabled directory browsing).' Green
        }
    }
}

function Invoke-DepAndRdp {
    Write-Log '[*] Enabling DEP AlwaysOn and RDP NLA...' Cyan
    if ($PSCmdlet.ShouldProcess('bcdedit nx', 'Set DEP AlwaysOn')) {
        & bcdedit.exe /set '{current}' nx AlwaysOn | Out-Null
    }
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -Name 'UserAuthentication' -Value 1
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -Name 'fDisableEncryption' -Value 0
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server' -Name 'fDenyTSConnections' -Value 0
    Write-Log '[+] DEP AlwaysOn & RDP NLA configured.' Green
}

function Invoke-StickyKeysRemoval {
    Write-Log '[*] Removing accessibility backdoor IFEO debuggers and binaries...' Yellow
    $bins = @('sethc.exe', 'Utilman.exe', 'osk.exe', 'Narrator.exe', 'Magnify.exe')
    foreach ($b in $bins) {
        $ifeo = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\$b"
        if (Test-Path $ifeo) {
            if ($PSCmdlet.ShouldProcess($ifeo, 'Remove IFEO Debugger')) {
                Remove-ItemProperty -Path $ifeo -Name 'Debugger' -Force -ErrorAction SilentlyContinue
            }
        }
        $exePath = Join-Path "$env:SystemRoot\System32" $b
        if (Test-Path $exePath) {
            if ($PSCmdlet.ShouldProcess($exePath, 'Take ownership and remove accessibility binary')) {
                & takeown.exe /F $exePath /A | Out-Null
                & icacls.exe $exePath /grant 'Administrators:F' /Q | Out-Null
                Remove-Item -Path $exePath -Force -ErrorAction SilentlyContinue
                Write-Log "[+] Removed $exePath" Green
            }
        }
    }
}

function Invoke-DisableWinRM {
    Write-Log '[*] [Strict] Disabling WinRM / PSRemoting...' Yellow
    if ($PSCmdlet.ShouldProcess('WinRM', 'Disable PSRemoting and stop WinRM')) {
        Disable-PSRemoting -Force -ErrorAction SilentlyContinue
        Stop-Service -Name WinRM -Force -ErrorAction SilentlyContinue
        Set-Service -Name WinRM -StartupType Disabled -ErrorAction SilentlyContinue
        Write-Log '[+] WinRM disabled.' Green
    }
}

Write-Log "=== Starting 6-HostHardening (Profile=$Profile, Control=$Control) ===" Cyan

switch ($Control) {
    'BuiltInAccounts' { Invoke-BuiltInAccounts }
    'Defender'        { Invoke-DefenderHardening }
    'AuditPolicy'     { Invoke-AuditPolicy }
    'Logging'         { Invoke-LoggingHardening }
    'UacAndLsa'       { Invoke-UacAndLsa }
    'SmbAndNet'       { Invoke-SmbAndNet }
    'Services'        { Invoke-ServiceHardening }
    'DepAndRdp'       { Invoke-DepAndRdp }
    'StickyKeys'      { Invoke-StickyKeysRemoval }
    'DisableWinRM'    { Invoke-DisableWinRM }
    'All' {
        Invoke-BuiltInAccounts
        Invoke-DefenderHardening
        Invoke-AuditPolicy
        Invoke-LoggingHardening
        Invoke-UacAndLsa
        Invoke-SmbAndNet
        Invoke-ServiceHardening
        Invoke-DepAndRdp
        if ($RemoveStickyKeys -or $Profile -eq 'Strict') { Invoke-StickyKeysRemoval }
        if ($Profile -eq 'Strict') { Invoke-DisableWinRM }
    }
}

Write-Log "[+] 6-HostHardening complete. Log: $logPath" Green
