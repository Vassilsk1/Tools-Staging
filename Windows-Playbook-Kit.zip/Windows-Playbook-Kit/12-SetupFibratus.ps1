<#
.SYNOPSIS
    Downloads, installs, and starts Fibratus (realtime Windows EDR/threat sensor) on Windows 10/11 and Server 2016-2025.

.DESCRIPTION
    Replaces Malwarebytes (which does not support Windows Server). Uses the official Fibratus
    signed MSI from https://github.com/rabbitstack/fibratus/releases (or C:\tools\zips\fibratus-setup.msi
    if already staged by 0-StageTools.ps1), installs silently via msiexec, ensures the 'fibratus'
    Windows service is set to Automatic and Running, and keeps Windows Defender active.

.EXAMPLE
    .\12-SetupFibratus.ps1
    .\12-SetupFibratus.ps1 -MsiPath C:\tools\zips\fibratus-setup.msi
    .\12-SetupFibratus.ps1 -WhatIf
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$MsiPath = 'C:\tools\zips\fibratus-setup.msi',
    [string]$BaseDir = 'C:\tools',
    [switch]$ForceReinstall
)

$ErrorActionPreference = 'Continue'

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run 12-SetupFibratus.ps1 from an elevated (Administrator) PowerShell session.'
}

try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor 12288 } catch {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
}

$zipsDir = Join-Path $BaseDir 'zips'
if (-not (Test-Path $zipsDir)) { New-Item -ItemType Directory -Path $zipsDir -Force | Out-Null }

$svc = Get-Service -Name 'fibratus' -ErrorAction SilentlyContinue
if ($svc -and -not $ForceReinstall) {
    Write-Host '[=] Fibratus service is already installed.' -ForegroundColor DarkGray
} else {
    if (-not (Test-Path $MsiPath) -or $ForceReinstall) {
        if ($PSCmdlet.ShouldProcess($MsiPath, 'Download latest Fibratus MSI from GitHub Releases')) {
            Write-Host '[*] Querying latest Fibratus release from GitHub...' -ForegroundColor Cyan
            try {
                $rel = Invoke-RestMethod -Uri 'https://api.github.com/repos/rabbitstack/fibratus/releases/latest' -UseBasicParsing -TimeoutSec 30
                $asset = $rel.assets | Where-Object { $_.name -like '*amd64*.msi' -or $_.name -like '*.msi' } | Select-Object -First 1
                if (-not $asset) { throw 'No MSI asset found in latest Fibratus release.' }
                Write-Host "[*] Downloading $($asset.name)..." -ForegroundColor Cyan
                if (Get-Command curl.exe -ErrorAction SilentlyContinue) {
                    & curl.exe -fSL --ssl-no-revoke --connect-timeout 30 --max-time 180 -o $MsiPath $asset.browser_download_url
                }
                if (-not (Test-Path $MsiPath) -or ((Get-Item $MsiPath).Length -lt 100000)) {
                    Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $MsiPath -UseBasicParsing -TimeoutSec 180
                }
                Write-Host "[+] Downloaded Fibratus MSI -> $MsiPath" -ForegroundColor Green
            } catch {
                Write-Warning "GitHub MSI download failed ($($_.Exception.Message)); trying official install.fibratus.io..."
                $instScript = Invoke-RestMethod -Uri 'https://install.fibratus.io' -UseBasicParsing -TimeoutSec 30
                $sb = [scriptblock]::Create($instScript)
                & $sb -Force -SkipSignatureCheck
            }
        }
    }

    if (Test-Path $MsiPath) {
        if ($PSCmdlet.ShouldProcess($MsiPath, 'Install Fibratus silently via msiexec')) {
            Write-Host '[*] Installing Fibratus (silent MSI)...' -ForegroundColor Cyan
            $proc = Start-Process -FilePath 'msiexec.exe' -ArgumentList "/i `"$MsiPath`" /qn /norestart" -Wait -PassThru
            if ($proc.ExitCode -eq 0 -or $proc.ExitCode -eq 3010) {
                Write-Host '[+] Fibratus MSI installed successfully.' -ForegroundColor Green
            } else {
                Write-Warning "msiexec exited with code $($proc.ExitCode)."
            }
        }
    }
}

# Add Defender exclusion for Fibratus program directory so rules/YARA signatures are not quarantined
$fibDir = 'C:\Program Files\Fibratus'
if (Test-Path $fibDir) {
    if ($PSCmdlet.ShouldProcess($fibDir, 'Add Defender exclusion for Fibratus')) {
        Add-MpPreference -ExclusionPath $fibDir -ErrorAction SilentlyContinue
    }
}

# Start and enable Fibratus service
$svc = Get-Service -Name 'fibratus' -ErrorAction SilentlyContinue
if ($svc) {
    if ($PSCmdlet.ShouldProcess('fibratus', 'Set Automatic & Start service')) {
        Set-Service -Name 'fibratus' -StartupType Automatic -ErrorAction SilentlyContinue
        Start-Service -Name 'fibratus' -ErrorAction SilentlyContinue
        Write-Host "[+] Fibratus service status: $((Get-Service -Name 'fibratus').Status)" -ForegroundColor Green
    }
} else {
    Write-Host '[*] Fibratus installed. Run "fibratus run" in an elevated shell or check "C:\Program Files\Fibratus".' -ForegroundColor Cyan
}

Write-Host '[+] Fibratus setup complete (works on Windows 10/11 and Server 2016-2025).' -ForegroundColor Green
