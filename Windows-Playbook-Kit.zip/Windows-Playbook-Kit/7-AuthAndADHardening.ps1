<#
.SYNOPSIS
    Unified Authentication, Active Directory, ESC10, and Domain GPO Hardening.

.DESCRIPTION
    Works on both Workstations/Servers (local NTLMv2, anonymous restrictions, Hardened UNC paths)
    and Domain Controllers (Zerologon, noPac, AD Recycle Bin, OU deletion protection,
    AccountNotDelegated, ESC10 StrongCertificateBindingEnforcement, and Domain GPO push).
    LDAP signing remains gated behind -EnforceLdapSigning so scored Linux auth does not break.

.EXAMPLE
    .\7-AuthAndADHardening.ps1 -ClearPasswordNeverExpires
    .\7-AuthAndADHardening.ps1 -SkipGPO
    .\7-AuthAndADHardening.ps1 -DisableKerberosDesRc4 -AddProtectedUsers
    .\7-AuthAndADHardening.ps1 -Rollback
    .\7-AuthAndADHardening.ps1 -WhatIf
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [switch]$DisableKerberosDesRc4,
    [switch]$EnforceLdapSigning,
    [switch]$AddProtectedUsers,
    [switch]$ClearPasswordNeverExpires,
    [switch]$SkipGPO,
    [switch]$SkipSmbSigningGPO,
    [int]$MinPasswordLength = 8,
    [string[]]$Exclude = @('bta', 'bta_admin', 'seccdc', 'krbtgt'),
    [switch]$Rollback,
    [string]$LogDir = 'C:\tools\logs'
)

$ErrorActionPreference = 'Continue'

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run 7-AuthAndADHardening.ps1 from an elevated (Administrator) PowerShell session.'
}

if (-not (Test-Path $LogDir)) {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
}
$logPath = Join-Path $LogDir "AuthADHardening_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"

function Write-Log {
    param([string]$Message, [ConsoleColor]$Color = 'Gray')
    Add-Content -Path $logPath -Value "$(Get-Date -Format 's') $Message"
    Write-Host $Message -ForegroundColor $Color
}

function Set-RegValue {
    param([string]$Path, [string]$Name, [object]$Value, [string]$Type = 'DWord')
    if ($PSCmdlet.ShouldProcess("$Path\$Name", "Set $Type = $Value")) {
        if (-not (Test-Path $Path)) { New-Item -Path $Path -Force | Out-Null }
        New-ItemProperty -Path $Path -Name $Name -Value $Value -PropertyType $Type -Force | Out-Null
    }
}

$role = (Get-CimInstance Win32_ComputerSystem).DomainRole
$isDC = $role -in 4, 5

$excludeSet = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
foreach ($item in $Exclude) {
    foreach ($p in ($item -split ',')) {
        $t = $p.Trim()
        if ($t) { [void]$excludeSet.Add($t) }
    }
}

if ($Rollback) {
    Write-Log '[*] Rolling back Auth, Kerberos, LDAP, and ESC10 registry settings...' Yellow
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -Name 'LmCompatibilityLevel' -Value 3
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\Kerberos\Parameters' -Name 'SupportedEncryptionTypes' -Value 0
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\Kdc' -Name 'StrongCertificateBindingEnforcement' -Value 1
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\NTDS\Parameters' -Name 'LDAPServerIntegrity' -Value 1
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\NTDS\Parameters' -Name 'LDAPEnforceChannelBinding' -Value 0
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\LDAP' -Name 'LDAPClientIntegrity' -Value 1
    Write-Log '[+] Rollback complete.' Green
    return
}

# --- 1. Host Auth Controls (DC + Workstations) ---
Write-Log '[*] [DC + Workstations] Enforcing NTLMv2 (LmCompatibilityLevel=5), anonymous restrictions, and Hardened UNC paths...' Cyan
Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -Name 'LmCompatibilityLevel' -Value 5
Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -Name 'RestrictAnonymous' -Value 1
Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -Name 'RestrictAnonymousSAM' -Value 1
Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -Name 'DisableDomainCreds' -Value 1
Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' -Name 'RestrictNullSessAccess' -Value 1
Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters' -Name 'EnablePlainTextPassword' -Value 0

Set-RegValue -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths' -Name '\\*\SYSVOL' -Value 'RequireMutualAuthentication=1,RequireIntegrity=1' -Type String
Set-RegValue -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths' -Name '\\*\NETLOGON' -Value 'RequireMutualAuthentication=1,RequireIntegrity=1' -Type String

# --- 2. Domain Controller Controls (DC Only) ---
if ($isDC) {
    Import-Module ActiveDirectory -ErrorAction Stop
    Write-Log '[*] [DC Only] Domain Controller detected — applying AD, ESC10, and GPO hardening...' Cyan

    # Zerologon (CVE-2020-1472)
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters' -Name 'FullSecureChannelProtection' -Value 1
    if ($PSCmdlet.ShouldProcess('Netlogon vulnerablechannelallowlist', 'Remove allowlist')) {
        Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters' -Name 'vulnerablechannelallowlist' -Force -ErrorAction SilentlyContinue
    }

    # ESC10: Strong Certificate Mapping Enforcement on DC KDC (KB5014754)
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\Kdc' -Name 'StrongCertificateBindingEnforcement' -Value 2
    Write-Log '[+] Enabled StrongCertificateBindingEnforcement = 2 (ESC10 mitigation).' Green

    # noPac (ms-DS-MachineAccountQuota = 0)
    if ($PSCmdlet.ShouldProcess($env:USERDNSDOMAIN, 'Set ms-DS-MachineAccountQuota = 0')) {
        Set-ADDomain -Identity $env:USERDNSDOMAIN -Replace @{ 'ms-DS-MachineAccountQuota' = 0 } -ErrorAction SilentlyContinue
        Write-Log '[+] Set ms-DS-MachineAccountQuota = 0' Green
    }

    # Default Domain Password Policy (MinPasswordLength >= 8)
    $policy = Get-ADDefaultDomainPasswordPolicy -ErrorAction SilentlyContinue
    if ($policy -and $policy.MinPasswordLength -lt $MinPasswordLength) {
        if ($PSCmdlet.ShouldProcess('Default Domain Password Policy', "Set MinPasswordLength = $MinPasswordLength")) {
            Set-ADDefaultDomainPasswordPolicy -Identity $env:USERDNSDOMAIN -MinPasswordLength $MinPasswordLength -ErrorAction SilentlyContinue
            Write-Log "[+] Raised Default Domain MinPasswordLength to $MinPasswordLength" Green
        }
    }

    # AD Recycle Bin
    $rb = Get-ADOptionalFeature -Identity 'Recycle Bin Feature' -ErrorAction SilentlyContinue
    if ($rb -and (-not $rb.EnabledScopes)) {
        $forest = (Get-ADForest).Name
        if ($PSCmdlet.ShouldProcess($forest, 'Enable AD Recycle Bin Feature')) {
            Enable-ADOptionalFeature -Identity 'Recycle Bin Feature' -Scope ForestOrConfigurationSet -Target $forest -Confirm:$false -ErrorAction SilentlyContinue
            Write-Log '[+] Enabled AD Recycle Bin Feature' Green
        }
    }

    # Protect all OUs from accidental deletion
    Get-ADOrganizationalUnit -Filter * -Properties ProtectedFromAccidentalDeletion |
        Where-Object { -not $_.ProtectedFromAccidentalDeletion } |
        ForEach-Object {
            if ($PSCmdlet.ShouldProcess($_.DistinguishedName, 'Enable ProtectedFromAccidentalDeletion')) {
                Set-ADOrganizationalUnit -Identity $_.DistinguishedName -ProtectedFromAccidentalDeletion $true -ErrorAction SilentlyContinue
                Write-Log "[+] Protected OU from accidental deletion: $($_.Name)" Green
            }
        }

    # Mark privileged accounts as AccountNotDelegated ($true)
    $adminGroups = @('Domain Admins', 'Enterprise Admins', 'Administrators')
    $privUsers = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($grp in $adminGroups) {
        Get-ADGroupMember -Identity $grp -Recursive -ErrorAction SilentlyContinue |
            Where-Object { $_.objectClass -eq 'user' -and (-not $excludeSet.Contains($_.SamAccountName)) } |
            ForEach-Object { [void]$privUsers.Add($_.SamAccountName) }
    }
    foreach ($sam in $privUsers) {
        if ($PSCmdlet.ShouldProcess($sam, 'Set AccountNotDelegated = $true')) {
            Set-ADUser -Identity $sam -AccountNotDelegated $true -ErrorAction SilentlyContinue
            Write-Log "[+] Marked AccountNotDelegated: $sam" Green
        }
    }

    if ($ClearPasswordNeverExpires) {
        Get-ADUser -Filter 'Enabled -eq $true -and PasswordNeverExpires -eq $true' |
            Where-Object { -not $excludeSet.Contains($_.SamAccountName) } |
            ForEach-Object {
                if ($PSCmdlet.ShouldProcess($_.SamAccountName, 'Clear PasswordNeverExpires')) {
                    Set-ADUser -Identity $_.SamAccountName -PasswordNeverExpires $false -ErrorAction SilentlyContinue
                    Write-Log "[+] Cleared PasswordNeverExpires: $($_.SamAccountName)" Green
                }
            }
    }

    if ($AddProtectedUsers) {
        Write-Log '[!] Adding privileged accounts to Protected Users (breaks NTLM/delegation for these accounts)...' Yellow
        foreach ($sam in $privUsers) {
            if ($PSCmdlet.ShouldProcess($sam, 'Add to Protected Users')) {
                Add-ADGroupMember -Identity 'Protected Users' -Members $sam -ErrorAction SilentlyContinue
                Write-Log "[+] Added to Protected Users: $sam" Green
            }
        }
    }

    # --- Push Domain-Wide GPO Configs (Default Domain Policy + Default Domain Controllers Policy) ---
    if (-not $SkipGPO) {
        if (Get-Module -ListAvailable -Name GroupPolicy) {
            Import-Module GroupPolicy -ErrorAction SilentlyContinue
            Write-Log '[*] [DC -> Domain-Wide GPO] Pushing config & signing policies to Default Domain Policy...' Cyan
            $ddp = 'Default Domain Policy'
            $dcp = 'Default Domain Controllers Policy'

            if ($PSCmdlet.ShouldProcess($ddp, 'Configure NTLMv2, LLMNR off, Hardened UNC, PS Logging, 4688, SMB Signing')) {
                # NTLMv2 & NoLMHash
                Set-GPRegistryValue -Name $ddp -Key 'HKLM\SYSTEM\CurrentControlSet\Control\Lsa' -ValueName 'LmCompatibilityLevel' -Type DWord -Value 5 | Out-Null
                Set-GPRegistryValue -Name $ddp -Key 'HKLM\SYSTEM\CurrentControlSet\Control\Lsa' -ValueName 'NoLMHash' -Type DWord -Value 1 | Out-Null
                # LLMNR Off
                Set-GPRegistryValue -Name $ddp -Key 'HKLM\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' -ValueName 'EnableMultiCast' -Type DWord -Value 0 | Out-Null
                # Hardened UNC Paths (SYSVOL / NETLOGON)
                Set-GPRegistryValue -Name $ddp -Key 'HKLM\SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths' -ValueName '\\*\SYSVOL' -Type String -Value 'RequireMutualAuthentication=1,RequireIntegrity=1' | Out-Null
                Set-GPRegistryValue -Name $ddp -Key 'HKLM\SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths' -ValueName '\\*\NETLOGON' -Type String -Value 'RequireMutualAuthentication=1,RequireIntegrity=1' | Out-Null
                # PowerShell ScriptBlock & Module Logging + 4688 CLI
                Set-GPRegistryValue -Name $ddp -Key 'HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging' -ValueName 'EnableScriptBlockLogging' -Type DWord -Value 1 | Out-Null
                Set-GPRegistryValue -Name $ddp -Key 'HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging' -ValueName 'EnableModuleLogging' -Type DWord -Value 1 | Out-Null
                Set-GPRegistryValue -Name $ddp -Key 'HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging\ModuleNames' -ValueName '*' -Type String -Value '*' | Out-Null
                Set-GPRegistryValue -Name $ddp -Key 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit' -ValueName 'ProcessCreationIncludeCmdLine_Enabled' -Type DWord -Value 1 | Out-Null

                if (-not $SkipSmbSigningGPO) {
                    Set-GPRegistryValue -Name $ddp -Key 'HKLM\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' -ValueName 'RequireSecuritySignature' -Type DWord -Value 1 | Out-Null
                    Set-GPRegistryValue -Name $ddp -Key 'HKLM\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters' -ValueName 'RequireSecuritySignature' -Type DWord -Value 1 | Out-Null
                }
                Write-Log "[+] Updated '$ddp' (applies to DC + Workstations)." Green
            }

            if ($PSCmdlet.ShouldProcess($dcp, 'Force Subcategory Audit Policy Override on DCs')) {
                Set-GPRegistryValue -Name $dcp -Key 'HKLM\SYSTEM\CurrentControlSet\Control\Lsa' -ValueName 'SCENoApplyLegacyAuditPolicy' -Type DWord -Value 1 | Out-Null
                Write-Log "[+] Updated '$dcp' (applies to DCs)." Green
            }
        } else {
            Write-Warning 'GroupPolicy module not installed; skipped GPO push (local registry settings still applied).'
        }
    }
}

# --- 3. Gated Scored-Service-Sensitive Controls ---
if ($DisableKerberosDesRc4) {
    Write-Log '[!] Disabling Kerberos DES/RC4 (AES128/256 only: 0x18). Test Linux/Java/legacy services!' Yellow
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\Kerberos\Parameters' -Name 'SupportedEncryptionTypes' -Value 0x18
}

if ($EnforceLdapSigning) {
    Write-Log '[!] Enforcing LDAP Server/Client Signing & Channel Binding. May break Linux SSSD/realm join!' Yellow
    Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\LDAP' -Name 'LDAPClientIntegrity' -Value 2
    if ($isDC) {
        Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\NTDS\Parameters' -Name 'LDAPServerIntegrity' -Value 2
        Set-RegValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\NTDS\Parameters' -Name 'LDAPEnforceChannelBinding' -Value 1
    }
}

Write-Log "[+] 7-AuthAndADHardening complete. Log: $logPath" Green
