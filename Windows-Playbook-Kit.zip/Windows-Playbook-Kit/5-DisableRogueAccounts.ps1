<#
.SYNOPSIS
    Disables unauthorized local or Active Directory accounts using exempt.txt or single-account targeting.

.DESCRIPTION
    Combines ptb/Disable-UserAccounts.ps1 (bulk exempt.txt workflow) with 4-DisableUserAccount.ps1
    (single-account surgical disable). Automatically protects Black Team accounts (bta, bta_admin, seccdc).

.EXAMPLE
    .\5-DisableRogueAccounts.ps1 -ExemptFile .\exempt.txt
    .\5-DisableRogueAccounts.ps1 -ExemptFile .\exempt.txt -Scope AD -WhatIf
    .\5-DisableRogueAccounts.ps1 -Name rogue_user -Scope Local
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$Name,

    [string]$ExemptFile,

    [string[]]$Keep = @(),

    [ValidateSet('Auto', 'Local', 'AD')]
    [string]$Scope = 'Auto',

    [switch]$ForceBlackTeam,

    [string]$LogDir = 'C:\tools\logs'
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path $LogDir)) {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
}
$logPath = Join-Path $LogDir "DisableAccounts_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"

if ($Scope -eq 'Auto') {
    $role = (Get-CimInstance Win32_ComputerSystem).DomainRole
    $Scope = if ($role -in 4, 5) { 'AD' } else { 'Local' }
}

$protected = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
if (-not $ForceBlackTeam) {
    foreach ($b in @('bta', 'bta_admin', 'seccdc', 'krbtgt', 'Guest', 'DefaultAccount', 'WDAGUtilityAccount')) {
        [void]$protected.Add($b)
    }
}

foreach ($k in $Keep) {
    foreach ($part in ($k -split ',')) {
        $t = $part.Trim()
        if ($t) { [void]$protected.Add($t) }
    }
}

if ($ExemptFile) {
    if (-not (Test-Path $ExemptFile)) {
        throw "ExemptFile not found: $ExemptFile"
    }
    foreach ($line in (Get-Content -Path $ExemptFile)) {
        $t = ($line -replace '#.*$', '').Trim()
        if ($t) { [void]$protected.Add($t) }
    }
}

if (-not $Name -and -not $ExemptFile -and $Keep.Count -eq 0) {
    throw 'Specify either -Name <account> or -ExemptFile <path> (or -Keep user1,user2) to avoid disabling all accounts.'
}

if ($Scope -eq 'AD') {
    Import-Module ActiveDirectory -ErrorAction Stop
    if ($Name) {
        if ($protected.Contains($Name)) { throw "Refusing to disable protected account '$Name' without -ForceBlackTeam." }
        $targets = @(Get-ADUser -Identity $Name -ErrorAction Stop)
    } else {
        $targets = Get-ADUser -Filter 'Enabled -eq $true' | Where-Object { -not $protected.Contains($_.SamAccountName) }
    }

    foreach ($u in $targets) {
        if ($PSCmdlet.ShouldProcess($u.SamAccountName, 'Disable AD user account')) {
            Disable-ADAccount -Identity $u.SamAccountName -ErrorAction Stop
            Add-Content -Path $logPath -Value "$(Get-Date -Format 's') [DISABLED][AD] $($u.SamAccountName)"
            Write-Host "[+] Disabled AD user: $($u.SamAccountName)" -ForegroundColor Green
        }
    }
} else {
    if ($Name) {
        if ($protected.Contains($Name)) { throw "Refusing to disable protected account '$Name' without -ForceBlackTeam." }
        $targets = @(Get-LocalUser -Name $Name -ErrorAction Stop)
    } else {
        $targets = Get-LocalUser | Where-Object { $_.Enabled -and (-not $protected.Contains($_.Name)) }
    }

    foreach ($u in $targets) {
        if ($PSCmdlet.ShouldProcess($u.Name, 'Disable local user account')) {
            Disable-LocalUser -Name $u.Name -ErrorAction Stop
            Add-Content -Path $logPath -Value "$(Get-Date -Format 's') [DISABLED][LOCAL] $($u.Name)"
            Write-Host "[+] Disabled local user: $($u.Name)" -ForegroundColor Green
        }
    }
}

Write-Host "[+] Log saved to $logPath" -ForegroundColor Cyan
